<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'dl');
define('DB_PASS', 'dl');
define('DB_NAME', 'dl');
define('BASE_URL', 'http://dl.sg.gy');

// 连接数据库
function get_db_connection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        error_log("数据库连接失败: " . $conn->connect_error);
        return false;
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

// 初始化数据库表
function init_database() {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }
    
    // 创建主表
    $sql = "CREATE TABLE IF NOT EXISTS short_urls (
        id INT AUTO_INCREMENT PRIMARY KEY,
        long_url TEXT NOT NULL,
        short_code VARCHAR(10) UNIQUE NOT NULL,
        clicks INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (!$conn->query($sql)) {
        error_log("创建表失败: " . $conn->error);
        $conn->close();
        return false;
    }
    
    $conn->close();
    return true;
}

// 验证URL格式
function validate_url($url) {
    if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
        $url = "http://" . $url;
    }
    return filter_var($url, FILTER_VALIDATE_URL) !== false ? $url : false;
}

// 创建短链接
function create_short_url($long_url, $title = '') {
    $conn = get_db_connection();
    if (!$conn) {
        error_log("数据库连接失败");
        return false;
    }
    
    // 确保数据库表存在
    if (!init_database()) {
        $conn->close();
        return false;
    }
    
    $short_code = generate_short_code();
    
    $sql = "INSERT INTO short_urls (long_url, short_code) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    
    // 检查prepare是否成功
    if (!$stmt) {
        error_log("预处理语句失败: " . $conn->error);
        $conn->close();
        return false;
    }
    
    // 绑定参数
    $stmt->bind_param("ss", $long_url, $short_code);
    
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        return $short_code;
    } else {
        error_log("执行失败: " . $stmt->error);
        $stmt->close();
        $conn->close();
        return false;
    }
}

// 生成随机短代码（避免重复）
function generate_short_code($length = 6) {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }
    
    do {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $short_code = '';
        for ($i = 0; $i < $length; $i++) {
            $short_code .= $characters[rand(0, strlen($characters) - 1)];
        }
        
        // 检查是否已存在
        $check_sql = "SELECT id FROM short_urls WHERE short_code = ?";
        $check_stmt = $conn->prepare($check_sql);
        
        if ($check_stmt) {
            $check_stmt->bind_param("s", $short_code);
            $check_stmt->execute();
            $exists = $check_stmt->get_result()->num_rows > 0;
            $check_stmt->close();
        } else {
            $exists = false;
        }
    } while ($exists);
    
    $conn->close();
    return $short_code;
}

// 验证验证码
function validate_captcha($user_input) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['captcha_code']) || !isset($_SESSION['captcha_expire'])) {
        return false;
    }
    
    if (time() > $_SESSION['captcha_expire']) {
        unset($_SESSION['captcha_code']);
        unset($_SESSION['captcha_expire']);
        return false;
    }
    
    $result = (strtolower(trim($user_input)) === strtolower($_SESSION['captcha_code']));
    
    if ($result) {
        unset($_SESSION['captcha_code']);
        unset($_SESSION['captcha_expire']);
    }
    
    return $result;
}

// 根据短代码获取长链接
function get_long_url($short_code) {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }
    
    $sql = "SELECT long_url FROM short_urls WHERE short_code = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        $conn->close();
        return false;
    }
    
    $stmt->bind_param("s", $short_code);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $long_url = $row['long_url'];
        
        // 更新点击次数
        $update_sql = "UPDATE short_urls SET clicks = clicks + 1 WHERE short_code = ?";
        $update_stmt = $conn->prepare($update_sql);
        
        if ($update_stmt) {
            $update_stmt->bind_param("s", $short_code);
            $update_stmt->execute();
            $update_stmt->close();
        }
        
        $stmt->close();
        $conn->close();
        
        return $long_url;
    }
    
    $stmt->close();
    $conn->close();
    return false;
}

// 获取所有短链接统计
function get_all_urls() {
    $conn = get_db_connection();
    if (!$conn) {
        return array();
    }
    
    // 确保表存在
    init_database();
    
    $sql = "SELECT * FROM short_urls ORDER BY created_at DESC";
    $result = $conn->query($sql);
    
    $urls = array();
    
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $urls[] = $row;
        }
    }
    
    $conn->close();
    return $urls;
}

// 获取URL统计
function get_url_stats($short_code) {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }
    
    $sql = "SELECT * FROM short_urls WHERE short_code = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        $conn->close();
        return false;
    }
    
    $stmt->bind_param("s", $short_code);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        return false;
    }
    
    $stats = $result->fetch_assoc();
    
    $stmt->close();
    $conn->close();
    return $stats;
}

// 获取总体统计信息
function get_overall_stats() {
    $conn = get_db_connection();
    if (!$conn) {
        return [
            'total_links' => 0,
            'total_clicks' => 0,
            'total_unique_visitors' => 0,
            'today_clicks' => 0
        ];
    }
    
    $stats = [
        'total_links' => 0,
        'total_clicks' => 0,
        'total_unique_visitors' => 0,
        'today_clicks' => 0
    ];
    
    // 确保表存在
    $check_table = $conn->query("SHOW TABLES LIKE 'short_urls'");
    if ($check_table && $check_table->num_rows > 0) {
        // 总链接数和点击数
        $sql1 = "SELECT COUNT(*) as total_links, 
                        SUM(COALESCE(clicks, 0)) as total_clicks
                 FROM short_urls";
        $result1 = $conn->query($sql1);
        if ($result1 && $row = $result1->fetch_assoc()) {
            $stats['total_links'] = $row['total_links'] ?: 0;
            $stats['total_clicks'] = $row['total_clicks'] ?: 0;
        }
    }
    
    $conn->close();
    return $stats;
}

// 删除短链接
function delete_short_url($short_code) {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }
    
    $sql = "DELETE FROM short_urls WHERE short_code = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        $conn->close();
        return false;
    }
    
    $stmt->bind_param("s", $short_code);
    $result = $stmt->execute();
    
    $stmt->close();
    $conn->close();
    return $result;
}

// 更新短链接状态
function update_url_status($short_code, $is_active) {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }
    
    $sql = "UPDATE short_urls SET is_active = ? WHERE short_code = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        $conn->close();
        return false;
    }
    
    $stmt->bind_param("is", $is_active, $short_code);
    $result = $stmt->execute();
    
    $stmt->close();
    $conn->close();
    return $result;
}

// 获取短链接的完整URL
function get_short_url($short_code) {
    return BASE_URL . '/' . $short_code;
}

// 初始化数据库（在文件加载时执行）
init_database();
?>