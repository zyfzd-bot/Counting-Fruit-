<?php
require_once 'includes/functions.php';

// 启动 Session（用于记录访问日志）
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 获取短代码
$request_uri = $_SERVER['REQUEST_URI'];
$short_code = ltrim($request_uri, '/');

// 排除首页和其他文件
if (empty($short_code) || 
    $short_code == 'index.php' || 
    $short_code == 'stats.php' ||
    strpos($short_code, '.php') !== false ||
    strpos($short_code, 'captcha.php') !== false) {
    header("Location: " . BASE_URL);
    exit;
}

// 获取长链接
$long_url = get_long_url($short_code);

if ($long_url) {
    // 记录访问日志
    log_access($short_code);
    
    // 重定向到长链接
    header("Location: " . $long_url, true, 301);
    exit;
} else {
    // 没有找到对应的短链接，跳转到首页
    header("Location: " . BASE_URL . "?error=链接不存在");
    exit;
}

// 记录访问日志的函数
function log_access($short_code) {
    $conn = get_db_connection();
    
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    
    // 简单设备检测
    $device_type = 'Desktop';
    if (strpos($user_agent, 'Mobile') !== false) {
        $device_type = 'Mobile';
    } elseif (strpos($user_agent, 'Tablet') !== false) {
        $device_type = 'Tablet';
    }
    
    // 插入访问记录
    $sql = "INSERT INTO access_logs (short_code, ip_address, user_agent, referer, device_type) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $short_code, $ip_address, $user_agent, $referer, $device_type);
    $stmt->execute();
    
    // 更新最后访问时间和独立访客数
    $update_sql = "UPDATE short_urls 
                   SET clicks = clicks + 1, 
                       last_accessed = NOW(),
                       unique_visitors = (SELECT COUNT(DISTINCT ip_address) FROM access_logs WHERE short_code = ?)
                   WHERE short_code = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ss", $short_code, $short_code);
    $update_stmt->execute();
    
    $conn->close();
}
?>