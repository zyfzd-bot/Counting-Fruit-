<?php
// 数据库配置 - 使用 defined 检查防止常量重复定义
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'dl');
if (!defined('DB_PASS')) define('DB_PASS', 'dl');
if (!defined('DB_NAME')) define('DB_NAME', 'dl');
if (!defined('BASE_URL')) define('BASE_URL', 'http://dl.sg.gy');

// 强制初始化数据库
if (!function_exists('force_init_database')) {
    function force_init_database() {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
        if ($conn->connect_error) {
            die("数据库连接失败: " . $conn->connect_error);
        }
        
        // 创建数据库
        $conn->query("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn->select_db(DB_NAME);
        
        // 创建表
        $tables = [
            "CREATE TABLE IF NOT EXISTS short_urls (
                id INT AUTO_INCREMENT PRIMARY KEY,
                long_url TEXT NOT NULL,
                short_code VARCHAR(20) UNIQUE NOT NULL,
                clicks INT DEFAULT 0,
                unique_visitors INT DEFAULT 0,
                last_accessed TIMESTAMP NULL,
                title VARCHAR(255) DEFAULT '',
                is_active TINYINT DEFAULT 1,
                expiry_date TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS short_url_access_log (
                id INT AUTO_INCREMENT PRIMARY KEY,
                short_code VARCHAR(20) NOT NULL,
                ip_address VARCHAR(45),
                user_agent TEXT,
                referer TEXT,
                device_type VARCHAR(50),
                browser VARCHAR(100),
                platform VARCHAR(100),
                access_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_short_code (short_code),
                INDEX idx_access_time (access_time)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            
            "CREATE TABLE IF NOT EXISTS short_url_device_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                short_code VARCHAR(20) NOT NULL,
                device_type VARCHAR(50),
                access_count INT DEFAULT 0,
                last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_device (short_code, device_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        ];
        
        foreach ($tables as $sql) {
            $conn->query($sql);
        }
        
        // 确保字段存在
        $columns_check = [
            "ALTER TABLE `short_urls` ADD COLUMN `title` VARCHAR(255) DEFAULT ''",
            "ALTER TABLE `short_urls` ADD COLUMN `is_active` TINYINT DEFAULT 1",
            "ALTER TABLE `short_urls` ADD COLUMN `expiry_date` TIMESTAMP NULL",
            "ALTER TABLE `short_urls` ADD COLUMN `last_accessed` TIMESTAMP NULL"
        ];
        
        foreach ($columns_check as $sql) {
            try {
                @$conn->query($sql);
            } catch (Exception $e) {
                // 忽略字段已存在的错误
            }
        }
        
        $conn->close();
    }
}

// 执行强制初始化
force_init_database();

// 连接数据库
if (!function_exists('get_db_connection')) {
    function get_db_connection() {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            error_log("数据库连接失败: " . $conn->connect_error);
            return false;
        }
        $conn->set_charset("utf8mb4");
        return $conn;
    }
}

// 验证URL格式
if (!function_exists('validate_url')) {
    function validate_url($url) {
        if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
            $url = "http://" . $url;
        }
        return filter_var($url, FILTER_VALIDATE_URL) !== false ? $url : false;
    }
}

// 验证自定义短链格式
if (!function_exists('validate_custom_short_code')) {
    function validate_custom_short_code($short_code) {
        return preg_match('/^[a-zA-Z0-9_-]{3,20}$/', $short_code);
    }
}

// 检查短代码是否存在
if (!function_exists('short_code_exists')) {
    function short_code_exists($short_code) {
        $conn = get_db_connection();
        if (!$conn) return false;
        
        $sql = "SELECT id FROM short_urls WHERE short_code = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $conn->close();
            return false;
        }
        
        $stmt->bind_param("s", $short_code);
        $stmt->execute();
        $result = $stmt->get_result();
        $exists = $result->num_rows > 0;
        
        $stmt->close();
        $conn->close();
        return $exists;
    }
}

// 创建短链接
if (!function_exists('create_short_url')) {
    function create_short_url($long_url, $custom_short_code = '', $title = '') {
        $conn = get_db_connection();
        if (!$conn) return false;
        
        if (!empty($custom_short_code)) {
            if (!validate_custom_short_code($custom_short_code)) {
                $conn->close();
                return 'invalid_format';
            }
            if (short_code_exists($custom_short_code)) {
                $conn->close();
                return 'already_exists';
            }
            $short_code = $custom_short_code;
        } else {
            $short_code = generate_short_code();
        }
        
        $sql = "INSERT INTO short_urls (long_url, short_code, title) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            $conn->close();
            return false;
        }
        
        $stmt->bind_param("sss", $long_url, $short_code, $title);
        
        if ($stmt->execute()) {
            $stmt->close();
            $conn->close();
            return $short_code;
        } else {
            $stmt->close();
            $conn->close();
            return false;
        }
    }
}

// 生成随机短代码
if (!function_exists('generate_short_code')) {
    function generate_short_code($length = 6) {
        $conn = get_db_connection();
        if (!$conn) return false;
        
        do {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $short_code = '';
            for ($i = 0; $i < $length; $i++) {
                $short_code .= $characters[rand(0, strlen($characters) - 1)];
            }
            if (short_code_exists($short_code)) {
                $exists = true;
            } else {
                $exists = false;
            }
        } while ($exists);
        
        $conn->close();
        return $short_code;
    }
}

// 验证验证码
if (!function_exists('validate_captcha')) {
    function validate_captcha($user_input) {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['captcha_code']) || !isset($_SESSION['captcha_expire'])) {
            return false;
        }
        if (time() > $_SESSION['captcha_expire']) {
            unset($_SESSION['captcha_code']);
            unset($_SESSION['captcha_expire']);
            return false;
        }
        $result = (strtolower(trim($user_input)) === strtolower($_SESSION['captcha_code']));
        if ($result) {
            unset($_SESSION['captcha_code']);
            unset($_SESSION['captcha_expire']);
        }
        return $result;
    }
}

// 获取长链接
if (!function_exists('get_long_url')) {
    function get_long_url($short_code) {
        $conn = get_db_connection();
        if (!$conn) return false;
        
        $sql = "SELECT long_url, is_active, expiry_date FROM short_urls WHERE short_code = ?";
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            $conn->close();
            return false;
        }
        
        $stmt->bind_param("s", $short_code);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            if (!$row['is_active']) {
                $stmt->close();
                $conn->close();
                return false;
            }
            
            if ($row['expiry_date'] && strtotime($row['expiry_date']) < time()) {
                $stmt->close();
                $conn->close();
                return false;
            }
            
            $stmt->close();
            $conn->close();
            
            // 触发日志记录
            if (function_exists('log_access')) {
                log_access($short_code);
            }
            
            return $row['long_url'];
        }
        
        $stmt->close();
        $conn->close();
        return false;
    }
}

// 记录日志 (增强版：修复重复写入)
if (!function_exists('log_access')) {
    function log_access($short_code) {
        $conn = get_db_connection();
        if (!$conn) return;

        // 1. 过滤非 GET 请求 (如 HEAD 请求)
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $conn->close();
            return;
        }
        
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        
        // 2. 机器人过滤
        if (preg_match('/bot|crawl|spider|slurp|facebookexternalhit|whatsapp|preview|curl|wget/i', $user_agent)) {
            $conn->close();
            return; 
        }

        // 3. 数据库级防抖动 (关键修复)
        // 检查该 IP 在最近 5 秒内是否已经记录过该短链
        $time_check_sql = "SELECT access_time FROM short_url_access_log WHERE short_code = ? AND ip_address = ? ORDER BY id DESC LIMIT 1";
        $time_stmt = $conn->prepare($time_check_sql);
        if ($time_stmt) {
            $time_stmt->bind_param("ss", $short_code, $ip_address);
            $time_stmt->execute();
            $time_result = $time_stmt->get_result();
            if ($row = $time_result->fetch_assoc()) {
                // 如果最近一条记录在 5 秒内，则不重复写入
                if (time() - strtotime($row['access_time']) < 5) {
                    $time_stmt->close();
                    $conn->close();
                    return; // 直接退出，不记录，不计数
                }
            }
            $time_stmt->close();
        }

        // 4. 检查是否为独立访客 (UV)
        $is_unique = false;
        $check_sql = "SELECT id FROM short_url_access_log WHERE short_code = ? AND ip_address = ? LIMIT 1";
        $check_stmt = $conn->prepare($check_sql);
        if ($check_stmt) {
            $check_stmt->bind_param("ss", $short_code, $ip_address);
            $check_stmt->execute();
            $check_stmt->store_result();
            if ($check_stmt->num_rows === 0) {
                $is_unique = true;
            }
            $check_stmt->close();
        }

        // 5. 插入访问日志 (使用现有表结构)
        $device_info = parse_user_agent($user_agent);
        $log_sql = "INSERT INTO short_url_access_log (short_code, ip_address, user_agent, referer, device_type, browser, platform) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $log_stmt = $conn->prepare($log_sql);
        if ($log_stmt) {
            $log_stmt->bind_param("sssssss", $short_code, $ip_address, $user_agent, $referer, $device_info['device_type'], $device_info['browser'], $device_info['platform']);
            $log_stmt->execute();
            $log_stmt->close();
        }

        // 6. 更新主表统计
        $update_sql = "UPDATE short_urls SET clicks = clicks + 1, last_accessed = CURRENT_TIMESTAMP";
        if ($is_unique) {
            $update_sql .= ", unique_visitors = unique_visitors + 1";
        }
        $update_sql .= " WHERE short_code = ?";
        
        $update_stmt = $conn->prepare($update_sql);
        if ($update_stmt) {
            $update_stmt->bind_param("s", $short_code);
            $update_stmt->execute();
            $update_stmt->close();
        }
        
        // 7. 更新设备统计表
        update_device_stats($short_code, $device_info['device_type']);
        
        $conn->close();
    }
}

// 解析 User Agent
if (!function_exists('parse_user_agent')) {
    function parse_user_agent($user_agent) {
        $device_type = 'Desktop';
        $browser = 'Unknown';
        $platform = 'Unknown';
        
        if (preg_match('/(mobile|android|iphone|ipod|blackberry|opera mini)/i', $user_agent)) {
            $device_type = 'Mobile';
        } elseif (preg_match('/(tablet|ipad|playbook)/i', $user_agent)) {
            $device_type = 'Tablet';
        }
        
        if (preg_match('/chrome/i', $user_agent)) {
            $browser = 'Chrome';
        } elseif (preg_match('/firefox/i', $user_agent)) {
            $browser = 'Firefox';
        } elseif (preg_match('/safari/i', $user_agent) && !preg_match('/chrome/i', $user_agent)) {
            $browser = 'Safari';
        } elseif (preg_match('/edge/i', $user_agent)) {
            $browser = 'Edge';
        }
        
        if (preg_match('/windows/i', $user_agent)) {
            $platform = 'Windows';
        } elseif (preg_match('/macintosh|mac os/i', $user_agent)) {
            $platform = 'MacOS';
        } elseif (preg_match('/android/i', $user_agent)) {
            $platform = 'Android';
        } elseif (preg_match('/iphone|ipad/i', $user_agent)) {
            $platform = 'iOS';
        }
        
        return [
            'device_type' => $device_type,
            'browser' => $browser,
            'platform' => $platform
        ];
    }
}

// 更新设备统计表
if (!function_exists('update_device_stats')) {
    function update_device_stats($short_code, $device_type) {
        $conn = get_db_connection();
        if (!$conn) return;
        
        $sql = "INSERT INTO short_url_device_stats (short_code, device_type, access_count) 
                VALUES (?, ?, 1) 
                ON DUPLICATE KEY UPDATE access_count = access_count + 1, last_accessed = CURRENT_TIMESTAMP";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("ss", $short_code, $device_type);
            $stmt->execute();
            $stmt->close();
        }
        $conn->close();
    }
}

// 获取统计信息
if (!function_exists('get_url_stats')) {
    function get_url_stats($short_code) {
        $conn = get_db_connection();
        if (!$conn) return false;
        
        $sql = "SELECT * FROM short_urls WHERE short_code = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $short_code);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $stmt->close();
            $conn->close();
            return false;
        }
        $stats = $result->fetch_assoc();
        $stmt->close();
        
        $check_table = $conn->query("SHOW TABLES LIKE 'short_url_access_log'");
        if ($check_table && $check_table->num_rows > 0) {
            
            $device_sql = "SELECT device_type, access_count FROM short_url_device_stats WHERE short_code = ?";
            $device_stmt = $conn->prepare($device_sql);
            if ($device_stmt) {
                $device_stmt->bind_param("s", $short_code);
                $device_stmt->execute();
                $res = $device_stmt->get_result();
                $stats['device_distribution'] = [];
                while ($row = $res->fetch_assoc()) {
                    $stats['device_distribution'][$row['device_type']] = $row['access_count'];
                }
                $device_stmt->close();
            }
            
            $recent_sql = "SELECT * FROM short_url_access_log WHERE short_code = ? ORDER BY access_time DESC LIMIT 10";
            $recent_stmt = $conn->prepare($recent_sql);
            if ($recent_stmt) {
                $recent_stmt->bind_param("s", $short_code);
                $recent_stmt->execute();
                $res = $recent_stmt->get_result();
                $stats['recent_access'] = [];
                while ($row = $res->fetch_assoc()) {
                    $stats['recent_access'][] = $row;
                }
                $recent_stmt->close();
            }
            
            $hourly_sql = "SELECT HOUR(access_time) as hour, COUNT(*) as count 
                           FROM short_url_access_log 
                           WHERE short_code = ? AND access_time >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                           GROUP BY HOUR(access_time)";
            $hourly_stmt = $conn->prepare($hourly_sql);
            if ($hourly_stmt) {
                $hourly_stmt->bind_param("s", $short_code);
                $hourly_stmt->execute();
                $res = $hourly_stmt->get_result();
                $stats['hourly_distribution'] = array_fill(0, 24, 0);
                while ($row = $res->fetch_assoc()) {
                    $stats['hourly_distribution'][$row['hour']] = $row['count'];
                }
                $hourly_stmt->close();
            }
            
            $browser_sql = "SELECT browser, COUNT(*) as count FROM short_url_access_log WHERE short_code = ? GROUP BY browser";
            $browser_stmt = $conn->prepare($browser_sql);
            if ($browser_stmt) {
                $browser_stmt->bind_param("s", $short_code);
                $browser_stmt->execute();
                $res = $browser_stmt->get_result();
                $stats['browser_distribution'] = [];
                while ($row = $res->fetch_assoc()) {
                    $stats['browser_distribution'][$row['browser']] = $row['count'];
                }
                $browser_stmt->close();
            }
            
        } else {
            $stats['device_distribution'] = [];
            $stats['recent_access'] = [];
            $stats['hourly_distribution'] = array_fill(0, 24, 0);
            $stats['browser_distribution'] = [];
        }
        
        $conn->close();
        return $stats;
    }
}

// Helper
if (!function_exists('get_short_url')) {
    function get_short_url($short_code) {
        return BASE_URL . '/' . $short_code;
    }
}
?>