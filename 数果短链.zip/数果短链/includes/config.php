<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'dl');
define('DB_USER', 'dl');
define('DB_PASS', 'dl');

// 网站配置
define('BASE_URL', 'https://dl.sg.gy/');
define('SHORT_URL_LENGTH', 7); // 短码长度