<?php
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 检查是否提供了短代码
$short_code = $_GET['code'] ?? '';
$stats = null;

if (!empty($short_code)) {
    $stats = get_url_stats($short_code);
    if (!$stats) {
        // 使用简单的错误跳转
        header("Location: index.php?error=链接不存在");
        exit;
    }
} else {
    // 如果没有 code 参数，跳转回首页
    header("Location: index.php");
    exit;
}

$current_year = date('Y');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据统计 - 数果短链</title>
    
    <!-- 引入 Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- 引入 Chart.js -->
    <script src="https://cdn.bootcdn.net/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    
    <!-- 引入 Google Fonts (国内镜像) -->
    <link href="https://fonts.loli.net/css2?family=Space+Grotesk:wght@400;500;700&family=Noto+Sans+SC:wght@400;500;700;900&display=swap" rel="stylesheet">
    
    <!-- 引入 Font Awesome (国内镜像) -->
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <!-- 配置 Tailwind 主题 -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Space Grotesk"', '"Noto Sans SC"', 'sans-serif'],
                    },
                    colors: {
                        'paper': '#fdfbf7',
                        'accent': '#a7f3d0',    // 薄荷绿
                        'primary': '#fbbf24',   // 亮黄
                        'secondary': '#f472b6', // 粉色
                        'blue-bold': '#60a5fa', // 亮蓝
                        'dark': '#18181b',
                    },
                    boxShadow: {
                        'hard': '4px 4px 0 0 #000',
                        'hard-sm': '2px 2px 0 0 #000',
                    }
                }
            }
        }
    </script>
    
    <style>
        .bg-pattern {
            background-color: #fdfbf7;
            background-image: radial-gradient(#d1d5db 1px, transparent 1px);
            background-size: 20px 20px;
        }
    </style>
</head>
<body class="bg-pattern min-h-screen text-dark font-medium pb-12">

    <!-- 顶部导航 -->
    <nav class="border-b-4 border-black bg-white py-4 px-6 sticky top-0 z-50 mb-8">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-primary border-2 border-black flex items-center justify-center shadow-hard-sm">
                    <i class="fas fa-chart-pie text-xl"></i>
                </div>
                <span class="text-2xl font-black tracking-tight hidden md:inline">数据<span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-500">透视</span></span>
            </div>
            
            <a href="index.php" class="bg-white border-2 border-black px-4 py-2 font-bold shadow-hard-sm hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-none transition-all hover:bg-gray-100 flex items-center gap-2">
                <i class="fas fa-arrow-left"></i> <span>返回首页</span>
            </a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-4 md:px-6 space-y-8">

        <?php if ($stats): ?>
            <!-- 核心信息卡片 -->
            <div class="bg-white border-4 border-black p-6 md:p-8 shadow-hard relative overflow-hidden">
                <!-- 装饰 -->
                <div class="absolute -right-6 -top-6 w-24 h-24 bg-accent rounded-full border-4 border-black z-0"></div>
                
                <div class="relative z-10">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
                        <div>
                            <h1 class="text-3xl md:text-4xl font-black mb-2">链接分析报告</h1>
                            <p class="text-gray-500 font-mono text-sm">Created: <?php echo date('Y-m-d H:i', strtotime($stats['created_at'])); ?></p>
                        </div>
                        <div class="flex gap-2">
                            <a href="<?php echo BASE_URL . '/' . $stats['short_code']; ?>" target="_blank" class="bg-primary text-black border-2 border-black px-4 py-2 font-bold shadow-hard-sm hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-none transition-all text-sm flex items-center gap-2">
                                <i class="fas fa-external-link-alt"></i> 访问短链
                            </a>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="bg-paper border-2 border-black p-4">
                            <span class="text-xs font-bold text-gray-500 uppercase tracking-wider block mb-1">短链接</span>
                            <div class="text-xl md:text-2xl font-mono font-bold text-blue-600 truncate">
                                <?php echo BASE_URL . '/' . $stats['short_code']; ?>
                            </div>
                        </div>
                        <div class="bg-paper border-2 border-black p-4">
                            <span class="text-xs font-bold text-gray-500 uppercase tracking-wider block mb-1">原始长链接</span>
                            <div class="text-sm md:text-base font-mono text-gray-700 break-all line-clamp-2" title="<?php echo htmlspecialchars($stats['long_url']); ?>">
                                <?php echo htmlspecialchars($stats['long_url']); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 数据概览 (4个卡片) -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                <!-- 总点击 -->
                <div class="bg-secondary border-2 border-black p-4 md:p-6 shadow-hard hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-2">
                        <i class="fas fa-mouse-pointer text-2xl text-white drop-shadow-[2px_2px_0_#000]"></i>
                    </div>
                    <div class="text-3xl md:text-4xl font-black text-white drop-shadow-[2px_2px_0_#000]"><?php echo isset($stats['clicks']) ? number_format($stats['clicks']) : 0; ?></div>
                    <div class="text-sm font-bold text-black mt-1">总点击次数</div>
                </div>

                <!-- 独立访客 -->
                <div class="bg-accent border-2 border-black p-4 md:p-6 shadow-hard hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-2">
                        <i class="fas fa-users text-2xl text-black"></i>
                    </div>
                    <div class="text-3xl md:text-4xl font-black text-black"><?php echo isset($stats['unique_visitors']) ? number_format($stats['unique_visitors']) : 0; ?></div>
                    <div class="text-sm font-bold text-black mt-1">独立访客 (UV)</div>
                </div>

                <!-- 24H 访问 -->
                <div class="bg-primary border-2 border-black p-4 md:p-6 shadow-hard hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-2">
                        <i class="fas fa-clock text-2xl text-black"></i>
                    </div>
                    <div class="text-3xl md:text-4xl font-black text-black">
                        <?php 
                            $today_clicks = 0;
                            if(isset($stats['hourly_distribution'])) {
                                $today_clicks = array_sum($stats['hourly_distribution']);
                            }
                            echo number_format($today_clicks);
                        ?>
                    </div>
                    <div class="text-sm font-bold text-black mt-1">近24小时点击</div>
                </div>

                <!-- 最后访问 -->
                <div class="bg-blue-bold border-2 border-black p-4 md:p-6 shadow-hard hover:-translate-y-1 transition-transform">
                    <div class="flex justify-between items-start mb-2">
                        <i class="fas fa-history text-2xl text-white drop-shadow-[2px_2px_0_#000]"></i>
                    </div>
                    <div class="text-lg md:text-xl font-black text-white drop-shadow-[2px_2px_0_#000] leading-tight mt-2 mb-1">
                        <?php echo isset($stats['last_accessed']) ? date('m-d H:i', strtotime($stats['last_accessed'])) : 'N/A'; ?>
                    </div>
                    <div class="text-sm font-bold text-black">最后访问时间</div>
                </div>
            </div>

            <!-- 图表区域 -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- 24小时趋势 -->
                <div class="bg-white border-2 border-black p-6 shadow-hard col-span-1 md:col-span-2">
                    <h3 class="text-xl font-black mb-6 flex items-center gap-2">
                        <span class="w-3 h-8 bg-black block"></span>
                        24小时点击趋势
                    </h3>
                    <div class="h-64 w-full">
                        <canvas id="clickChart"></canvas>
                    </div>
                </div>

                <!-- 设备分布 -->
                <div class="bg-white border-2 border-black p-6 shadow-hard">
                    <h3 class="text-xl font-black mb-6 flex items-center gap-2">
                        <span class="w-3 h-8 bg-secondary block"></span>
                        访问设备分布
                    </h3>
                    <div class="h-64 w-full flex justify-center">
                        <canvas id="deviceChart"></canvas>
                    </div>
                </div>

                <!-- 浏览器分布 -->
                <div class="bg-white border-2 border-black p-6 shadow-hard">
                    <h3 class="text-xl font-black mb-6 flex items-center gap-2">
                        <span class="w-3 h-8 bg-primary block"></span>
                        浏览器类型
                    </h3>
                    <div class="h-64 w-full flex justify-center">
                        <canvas id="browserChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- 最近访问记录 -->
            <div class="bg-white border-4 border-black p-6 shadow-hard mb-12">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-black flex items-center gap-2">
                        <span class="w-3 h-8 bg-accent block border border-black"></span>
                        最近 10 次访问
                    </h3>
                    <div class="text-xs font-bold bg-black text-white px-2 py-1">REAL-TIME</div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b-4 border-black text-sm font-black uppercase tracking-wider">
                                <th class="p-4 bg-paper">时间</th>
                                <th class="p-4 bg-paper">IP 地址</th>
                                <th class="p-4 bg-paper">设备/系统</th>
                                <th class="p-4 bg-paper hidden md:table-cell">浏览器</th>
                                <th class="p-4 bg-paper hidden md:table-cell">来源</th>
                            </tr>
                        </thead>
                        <tbody class="font-mono text-sm">
                            <?php if (isset($stats['recent_access']) && !empty($stats['recent_access'])): ?>
                                <?php foreach ($stats['recent_access'] as $index => $access): ?>
                                    <tr class="border-b-2 border-gray-100 hover:bg-yellow-50 transition-colors">
                                        <td class="p-4 font-bold text-black">
                                            <?php echo date('m-d H:i:s', strtotime($access['access_time'])); ?>
                                        </td>
                                        <td class="p-4 text-gray-600">
                                            <?php echo $access['ip_address']; ?>
                                        </td>
                                        <td class="p-4">
                                            <span class="inline-block bg-white border border-black px-2 py-0.5 text-xs font-bold shadow-[2px_2px_0_0_#000]">
                                                <?php echo $access['device_type']; ?>
                                            </span>
                                            <span class="text-xs text-gray-400 ml-1"><?php echo $access['platform']; ?></span>
                                        </td>
                                        <td class="p-4 hidden md:table-cell text-gray-600">
                                            <?php echo $access['browser']; ?>
                                        </td>
                                        <td class="p-4 hidden md:table-cell text-gray-500 text-xs truncate max-w-[150px]" title="<?php echo htmlspecialchars($access['referer']); ?>">
                                            <?php echo $access['referer'] ? htmlspecialchars($access['referer']) : '-'; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="p-8 text-center text-gray-400 italic">
                                        暂无访问记录，快去分享你的链接吧！
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php endif; ?>
    </div>

    <script>
        // 通用图表配置：加粗字体和黑色边框，符合粗野主义
        Chart.defaults.font.family = "'Space Grotesk', 'Noto Sans SC', sans-serif";
        Chart.defaults.color = '#000';
        Chart.defaults.borderColor = '#000'; // 网格线颜色
        Chart.defaults.plugins.tooltip.backgroundColor = '#000';
        Chart.defaults.plugins.tooltip.titleColor = '#fff';
        Chart.defaults.plugins.tooltip.padding = 10;
        Chart.defaults.plugins.tooltip.cornerRadius = 0; // 直角提示框
        Chart.defaults.plugins.tooltip.displayColors = false;

        // 1. 24小时点击趋势 (折线图)
        const clickCtx = document.getElementById('clickChart').getContext('2d');
        const clickChart = new Chart(clickCtx, {
            type: 'line',
            data: {
                labels: [
                    <?php
                    $hours = [];
                    for ($i = 0; $i < 24; $i++) {
                        $hours[] = sprintf("%02d:00", $i);
                    }
                    echo "'" . implode("','", $hours) . "'";
                    ?>
                ],
                datasets: [{
                    label: '点击量',
                    data: [
                        <?php
                        $hourData = [];
                        for ($i = 0; $i < 24; $i++) {
                            $hourData[] = isset($stats['hourly_distribution'][$i]) ? $stats['hourly_distribution'][$i] : 0;
                        }
                        echo implode(',', $hourData);
                        ?>
                    ],
                    borderColor: '#000',      // 黑色线条
                    backgroundColor: '#fbbf24', // 黄色填充
                    borderWidth: 3,
                    pointBackgroundColor: '#000',
                    pointBorderColor: '#000',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [2, 2], color: '#e5e7eb' },
                        ticks: { stepSize: 1, font: {weight: 'bold'} }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { maxTicksLimit: 8, font: {weight: 'bold'} }
                    }
                }
            }
        });

        // 2. 设备分布 (甜甜圈图)
        const deviceCtx = document.getElementById('deviceChart').getContext('2d');
        new Chart(deviceCtx, {
            type: 'doughnut',
            data: {
                labels: [
                    <?php
                    if (isset($stats['device_distribution']) && !empty($stats['device_distribution'])) {
                        $devices = array_keys($stats['device_distribution']);
                        echo "'" . implode("','", $devices) . "'";
                    } else { echo "'暂无数据'"; }
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php
                        if (isset($stats['device_distribution']) && !empty($stats['device_distribution'])) {
                            echo implode(',', array_values($stats['device_distribution']));
                        } else { echo "1"; }
                        ?>
                    ],
                    backgroundColor: [
                        '#fbbf24', // 黄
                        '#f472b6', // 粉
                        '#a7f3d0', // 绿
                        '#60a5fa', // 蓝
                        '#d1d5db'  // 灰
                    ],
                    borderColor: '#000',
                    borderWidth: 2,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'rect',
                            padding: 20,
                            font: { weight: 'bold' }
                        }
                    }
                }
            }
        });

        // 3. 浏览器分布 (饼图)
        const browserCtx = document.getElementById('browserChart').getContext('2d');
        new Chart(browserCtx, {
            type: 'pie',
            data: {
                labels: [
                    <?php
                    if (isset($stats['browser_distribution']) && !empty($stats['browser_distribution'])) {
                        $browsers = array_keys($stats['browser_distribution']);
                        echo "'" . implode("','", $browsers) . "'";
                    } else { echo "'暂无数据'"; }
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php
                        if (isset($stats['browser_distribution']) && !empty($stats['browser_distribution'])) {
                            echo implode(',', array_values($stats['browser_distribution']));
                        } else { echo "1"; }
                        ?>
                    ],
                    backgroundColor: [
                        '#f472b6', // 粉
                        '#60a5fa', // 蓝
                        '#fbbf24', // 黄
                        '#a7f3d0', // 绿
                        '#c084fc'  // 紫
                    ],
                    borderColor: '#000',
                    borderWidth: 2,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'rect',
                            padding: 20,
                            font: { weight: 'bold' }
                        }
                    }
                }
            }
        });

        // 自动刷新 (每30秒)
        setInterval(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>