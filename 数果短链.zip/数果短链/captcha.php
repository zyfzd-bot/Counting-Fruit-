<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header("Content-type: image/png");
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

$width = 120;
$height = 40;
$image = imagecreate($width, $height);

$bg_color = imagecolorallocate($image, 245, 245, 245);
$text_colors = array();
for ($i = 0; $i < 5; $i++) {
    $text_colors[] = imagecolorallocate($image, rand(50, 150), rand(50, 150), rand(50, 150));
}
$line_color = imagecolorallocate($image, 200, 200, 200);

imagefill($image, 0, 0, $bg_color);

$captcha = '';
for ($i = 0; $i < 4; $i++) {
    $captcha .= rand(0, 9);
}

$_SESSION['captcha_code'] = $captcha;
$_SESSION['captcha_expire'] = time() + 60;

for ($i = 0; $i < 5; $i++) {
    imageline($image, 
        rand(0, $width), rand(0, $height),
        rand(0, $width), rand(0, $height),
        $line_color);
}

$font_size = 5;
$text_width = imagefontwidth($font_size) * 4;
$text_height = imagefontheight($font_size);
$x = ($width - $text_width) / 2;
$y = ($height - $text_height) / 2 + $text_height;

for ($i = 0; $i < 4; $i++) {
    $char_color = $text_colors[rand(0, count($text_colors)-1)];
    $char_x = $x + ($i * imagefontwidth($font_size) * 1.8);
    $char_y = $y + rand(-2, 2);
    
    imagestring($image, $font_size, $char_x, $char_y, $captcha[$i], $char_color);
}

imagepng($image);
imagedestroy($image);
exit;
?>