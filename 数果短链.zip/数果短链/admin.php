<?php
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 简单的密码保护
$admin_password = 'admin123'; // 修改这个密码

if (!isset($_POST['password']) || $_POST['password'] !== $admin_password) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>管理员登录</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 400px; margin: 100px auto; padding: 20px; }
            .login-form { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
            input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { background: #3498db; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; }
        </style>
    </head>
    <body>
        <div class="login-form">
            <h2>管理员登录</h2>
            <form method="POST">
                <input type="password" name="password" placeholder="输入管理员密码" required>
                <button type="submit">登录</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// 处理删除操作
if (isset($_GET['delete'])) {
    $delete_code = $_GET['delete'];
    if (delete_short_url($delete_code)) {
        $message = "短链接已成功删除";
    } else {
        $error = "删除短链接失败";
    }
}

// 处理状态更新
if (isset($_GET['toggle_status'])) {
    $toggle_code = $_GET['toggle_status'];
    $current_status = isset($_GET['current']) ? (int)$_GET['current'] : 1;
    $new_status = $current_status ? 0 : 1;
    
    if (update_url_status($toggle_code, $new_status)) {
        $message = "链接状态已更新";
    } else {
        $error = "更新链接状态失败";
    }
}

// 获取URL数据
$urls = get_all_urls();
$overall_stats = get_overall_stats();

// 确保$urls是数组
if (!is_array($urls)) {
    $urls = array();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>管理面板 - 数果短链</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        table { width: 100%; background: white; border-collapse: collapse; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #3498db; color: white; }
        tr:hover { background: #f5f5f5; }
        .stats-card { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stats-card h2 { margin-top: 0; color: #333; }
        .btn { display: inline-block; background: #3498db; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; margin-right: 5px; }
        .btn:hover { background: #2980b9; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        .btn-warning { background: #f39c12; }
        .btn-warning:hover { background: #d35400; }
        .btn-success { background: #27ae60; }
        .btn-success:hover { background: #219a52; }
        .empty-state { text-align: center; padding: 40px; color: #666; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-item { background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stat-number { font-size: 24px; font-weight: bold; color: #3498db; }
        .stat-label { color: #666; margin-top: 5px; }
        .message { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .status-active { color: #27ae60; font-weight: bold; }
        .status-inactive { color: #e74c3c; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>数果短链 - 管理面板</h1>
            <a href="index.php" class="btn">返回首页</a>
        </div>

        <?php if (isset($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="stats-card">
            <h2>总览统计</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number"><?php echo $overall_stats['total_links']; ?></div>
                    <div class="stat-label">总链接数</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $overall_stats['total_clicks']; ?></div>
                    <div class="stat-label">总点击次数</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $overall_stats['total_unique_visitors']; ?></div>
                    <div class="stat-label">独立访客</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $overall_stats['today_clicks']; ?></div>
                    <div class="stat-label">今日点击</div>
                </div>
            </div>
        </div>

        <?php if (count($urls) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>短代码</th>
                    <th>原链接</th>
                    <th>点击次数</th>
                    <th>独立访客</th>
                    <th>状态</th>
                    <th>创建时间</th>
                    <th>最后访问</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($urls as $url): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($url['short_code']); ?></strong></td>
                    <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?php echo htmlspecialchars($url['long_url']); ?>">
                        <?php echo htmlspecialchars($url['long_url']); ?>
                    </td>
                    <td><?php echo isset($url['clicks']) ? $url['clicks'] : 0; ?></td>
                    <td><?php echo isset($url['unique_visitors']) ? $url['unique_visitors'] : 0; ?></td>
                    <td>
                        <?php if ($url['is_active']): ?>
                            <span class="status-active">活跃</span>
                        <?php else: ?>
                            <span class="status-inactive">禁用</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo isset($url['created_at']) ? date('Y-m-d H:i', strtotime($url['created_at'])) : '未知'; ?></td>
                    <td>
                        <?php if (isset($url['last_accessed']) && $url['last_accessed']): ?>
                            <?php echo date('Y-m-d H:i', strtotime($url['last_accessed'])); ?>
                        <?php else: ?>
                            从未访问
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo BASE_URL . '/' . $url['short_code']; ?>" target="_blank" class="btn">访问</a>
                        <a href="stats.php?code=<?php echo $url['short_code']; ?>" class="btn">统计</a>
                        <a href="?toggle_status=<?php echo $url['short_code']; ?>&current=<?php echo $url['is_active']; ?>" class="btn <?php echo $url['is_active'] ? 'btn-warning' : 'btn-success'; ?>">
                            <?php echo $url['is_active'] ? '禁用' : '启用'; ?>
                        </a>
                        <a href="?delete=<?php echo $url['short_code']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这个短链接吗？此操作不可撤销。')">删除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="stats-card empty-state">
            <h3>暂无短链接数据</h3>
            <p>还没有创建任何短链接，<a href="index.php">去创建第一个短链接</a></p>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>