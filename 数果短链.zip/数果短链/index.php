<?php
// 引入功能函数文件
require_once __DIR__ . '/includes/functions.php';

// 开启 Session (用于验证码)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$short_url = "";
$error = "";

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 获取并清理输入数据
    $long_url = isset($_POST['long_url']) ? trim($_POST['long_url']) : '';
    $captcha_answer = isset($_POST['captcha_answer']) ? trim($_POST['captcha_answer']) : '';
    $custom_enable = isset($_POST['custom_enable']) ? true : false;
    $custom_url = isset($_POST['custom_url']) ? trim($_POST['custom_url']) : '';
    
    // 1. 验证验证码
    if (empty($captcha_answer) || !validate_captcha($captcha_answer)) {
        $error = "验证码错误或已过期，请重新输入";
    } 
    // 2. 验证 URL 输入是否为空
    elseif (empty($long_url)) {
        $error = "请输入URL地址";
    } 
    else {
        // 3. 验证并获取标准化的 URL
        $validated_url = validate_url($long_url);

        if ($validated_url) {
            $long_url = $validated_url;

            // 4. 处理短链接生成
            if ($custom_enable && !empty($custom_url)) {
                $short_code = create_short_url($long_url, $custom_url);
                
                if ($short_code === 'invalid_format') {
                    $error = "后缀只能包含字母、数字、下划线 (3-20位)";
                } elseif ($short_code === 'already_exists') {
                    $error = "后缀 '" . htmlspecialchars($custom_url) . "' 已经被别人用啦";
                } elseif ($short_code) {
                    $short_url = BASE_URL . '/' . $short_code;
                } else {
                    $error = "服务器开小差了，请稍后重试";
                }
            } else {
                $short_code = create_short_url($long_url);
                
                if ($short_code) {
                    $short_url = BASE_URL . '/' . $short_code;
                } else {
                    $error = "服务器开小差了，请稍后重试";
                }
            }
        } else {
            $error = "这个 URL 看起来不对劲";
        }
    }
}

$current_year = date('Y');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数果短链 - 个性化短链接服务</title>
    
    <!-- 引入 Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- 引入 Google Fonts (使用 loli.net 国内镜像) -->
    <link href="https://fonts.loli.net/css2?family=Space+Grotesk:wght@400;500;700&family=Noto+Sans+SC:wght@400;500;700;900&display=swap" rel="stylesheet">
    
    <!-- 引入 Font Awesome (使用 BootCDN) -->
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <!-- 配置 Tailwind 主题 (新粗野主义风格) -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Space Grotesk"', '"Noto Sans SC"', 'sans-serif'],
                    },
                    colors: {
                        // 鲜艳的高饱和度颜色
                        'paper': '#fdfbf7',     // 米白纸张色
                        'accent': '#a7f3d0',    // 薄荷绿
                        'primary': '#fbbf24',   // 亮黄
                        'secondary': '#f472b6', // 粉色
                        'dark': '#18181b',      // 接近纯黑
                    },
                    boxShadow: {
                        // 硬阴影配置
                        'hard': '4px 4px 0 0 #000',
                        'hard-sm': '2px 2px 0 0 #000',
                        'hard-lg': '8px 8px 0 0 #000',
                        'hard-hover': '0px 0px 0 0 #000', // 点击时阴影消失
                    },
                    translate: {
                        'click': '4px',
                        'click-sm': '2px',
                    }
                }
            }
        }
    </script>
    
    <style>
        /* 点状背景图案 */
        .bg-pattern {
            background-color: #fdfbf7;
            background-image: radial-gradient(#d1d5db 1px, transparent 1px);
            background-size: 20px 20px;
        }
        
        /* 选中态样式 */
        ::selection {
            background-color: #fbbf24;
            color: #000;
        }
    </style>
</head>
<body class="bg-pattern min-h-screen text-dark flex flex-col font-medium">

    <!-- 顶部导航栏 -->
    <nav class="border-b-4 border-black bg-white py-4 px-6 sticky top-0 z-50">
        <div class="max-w-5xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-3 group cursor-pointer">
                <div class="w-10 h-10 bg-primary border-2 border-black flex items-center justify-center shadow-hard-sm group-hover:translate-x-[2px] group-hover:translate-y-[2px] group-hover:shadow-none transition-all duration-200">
                    <i class="fas fa-link text-xl"></i>
                </div>
                <span class="text-2xl font-black tracking-tight">数果<span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-red-500">短链</span></span>
            </div>
            
            <!-- 已移除开源按钮 -->
        </div>
    </nav>

    <!-- 主内容区 -->
    <main class="flex-grow flex items-center justify-center p-4 md:p-8">
        <div class="w-full max-w-2xl">
            
            <!-- 标题区 -->
            <div class="text-center mb-12 space-y-4">
                <div class="inline-block bg-accent border-2 border-black px-4 py-1 rounded-full text-sm font-bold shadow-hard-sm transform -rotate-2 mb-4">
                    ✨ 简单 · 快速 · 有趣
                </div>
                <h1 class="text-4xl md:text-6xl font-black text-dark leading-tight">
                    把你的长链接<br>
                    <span class="relative inline-block mt-2">
                        <span class="absolute inset-0 bg-primary transform -skew-y-2 translate-y-2 border-2 border-black -z-10"></span>
                        <span class="relative px-2">切短一点!</span>
                    </span>
                </h1>
                <p class="text-lg md:text-xl text-gray-600 max-w-lg mx-auto font-medium mt-6">
                    我们提供具有<b>手绘风格</b>的短链接生成服务。<br>不仅仅是工具，更是一种态度。
                </p>
            </div>

            <!-- 主卡片 -->
            <div class="bg-white border-4 border-black p-6 md:p-10 shadow-hard-lg relative">
                <!-- 装饰性元素 -->
                <div class="absolute -top-3 -right-3 w-8 h-8 bg-secondary border-2 border-black rounded-full z-10 flex items-center justify-center animate-bounce">
                    <div class="w-2 h-2 bg-white rounded-full"></div>
                </div>

                <?php if (isset($error) && !empty($error)): ?>
                    <div class="mb-8 bg-red-100 border-2 border-black p-4 flex items-start gap-4 shadow-hard-sm transform rotate-1">
                        <div class="text-2xl">😫</div>
                        <div>
                            <h3 class="font-bold text-red-600 text-lg">哎呀，出错了</h3>
                            <p class="text-red-800 font-medium"><?php echo htmlspecialchars($error); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (isset($short_url) && !empty($short_url)): ?>
                    <!-- 成功状态 -->
                    <div class="text-center py-4">
                        <div class="inline-block p-4 bg-green-400 border-2 border-black rounded-full shadow-hard mb-6">
                            <i class="fas fa-check text-3xl text-white drop-shadow-[2px_2px_0_rgba(0,0,0,1)]"></i>
                        </div>
                        <h2 class="text-3xl font-black mb-2">搞定啦!</h2>
                        <p class="text-gray-600 font-medium mb-8">链接已生成，快去分享吧</p>
                        
                        <div class="flex flex-col md:flex-row gap-4 mb-8">
                            <div class="flex-grow bg-paper border-2 border-black p-4 text-xl font-mono text-center md:text-left flex items-center truncate shadow-hard-sm">
                                <a href="<?php echo htmlspecialchars($short_url); ?>" id="result-link" target="_blank" class="w-full truncate hover:text-blue-600 underline decoration-2 underline-offset-4 decoration-black">
                                    <?php echo htmlspecialchars($short_url); ?>
                                </a>
                            </div>
                            <button onclick="copyLink()" class="bg-primary text-black border-2 border-black px-8 py-4 font-bold text-lg shadow-hard hover:translate-x-[4px] hover:translate-y-[4px] hover:shadow-none transition-all active:bg-yellow-500 whitespace-nowrap flex items-center justify-center gap-2">
                                <i class="fas fa-copy"></i> 复制
                            </button>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <a href="stats.php?code=<?php echo $short_code; ?>" target="_blank" class="flex items-center justify-center gap-2 bg-white border-2 border-black py-3 font-bold hover:bg-gray-50 transition-colors">
                                <i class="fas fa-chart-bar"></i> 看数据
                            </a>
                            <a href="index.php" class="flex items-center justify-center gap-2 bg-white border-2 border-black py-3 font-bold hover:bg-gray-50 transition-colors">
                                <i class="fas fa-redo"></i> 再来一个
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- 表单状态 -->
                    <form method="POST" action="" class="space-y-6">
                        
                        <!-- 输入框 -->
                        <div class="space-y-2">
                            <label class="font-bold text-lg ml-1">长链接地址</label>
                            <input type="url" name="long_url" required
                                class="w-full bg-paper border-2 border-black text-lg p-4 font-mono focus:outline-none focus:shadow-hard focus:-translate-y-1 focus:-translate-x-1 transition-all placeholder-gray-400" 
                                placeholder="在此粘贴你的超长链接..."
                                value="<?php echo isset($_POST['long_url']) ? htmlspecialchars($_POST['long_url']) : ''; ?>">
                        </div>

                        <!-- 自定义选项开关 -->
                        <div class="bg-blue-50 border-2 border-black p-4 shadow-hard-sm">
                            <label class="flex items-center cursor-pointer select-none">
                                <div class="relative">
                                    <input type="checkbox" id="custom_enable" name="custom_enable" class="sr-only peer" <?php echo isset($_POST['custom_enable']) ? 'checked' : ''; ?>>
                                    <div class="w-12 h-7 bg-white border-2 border-black rounded-full peer-checked:bg-secondary transition-colors"></div>
                                    <div class="absolute left-1 top-1 bg-black w-5 h-5 rounded-full border border-black transition-transform peer-checked:translate-x-5 peer-checked:bg-white"></div>
                                </div>
                                <span class="ml-3 font-bold">我要自定义后缀</span>
                            </label>

                            <div id="custom-area" class="mt-4 transition-all duration-200 overflow-hidden <?php echo isset($_POST['custom_enable']) ? 'max-h-32 opacity-100' : 'max-h-0 opacity-0'; ?>">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="font-mono text-gray-500 bg-white border border-black px-2 py-1 text-sm"><?php echo str_replace(['http://', 'https://'], '', BASE_URL); ?>/</span>
                                </div>
                                <input type="text" name="custom_url" id="custom_input"
                                    class="w-full bg-white border-2 border-black p-2 font-mono focus:outline-none focus:bg-yellow-50 placeholder-gray-400"
                                    placeholder="输入你的个性别名 (e.g. cool-stuff)"
                                    value="<?php echo isset($_POST['custom_url']) ? htmlspecialchars($_POST['custom_url']) : ''; ?>">
                            </div>
                        </div>

                        <!-- 验证码 -->
                        <div class="flex flex-row gap-2 md:gap-4 items-end">
                            <div class="flex-grow space-y-2">
                                <label class="font-bold text-lg ml-1">验证码</label>
                                <input type="text" name="captcha_answer" required maxlength="4"
                                    class="w-full bg-paper border-2 border-black text-lg p-4 font-mono focus:outline-none focus:shadow-hard focus:-translate-y-1 focus:-translate-x-1 transition-all uppercase placeholder-gray-400"
                                    placeholder="请输入验证码">
                            </div>
                            <div class="flex-shrink-0">
                                <div class="relative group cursor-pointer border-2 border-black shadow-hard-sm active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all bg-white h-[62px] w-28 md:w-32" onclick="refreshCaptcha()">
                                    <img src="captcha.php?t=<?php echo time(); ?>" id="captcha-img" class="w-full h-full object-cover" title="点击刷新">
                                    <div class="absolute inset-0 flex items-center justify-center bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <i class="fas fa-sync text-black text-xl font-bold"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- 提交按钮 -->
                        <button type="submit" class="w-full bg-dark text-white border-2 border-black py-5 text-xl font-black tracking-wider shadow-hard hover:bg-gray-800 hover:translate-x-[4px] hover:translate-y-[4px] hover:shadow-none transition-all active:scale-[0.99] flex items-center justify-center gap-3 mt-8">
                            <span>一键生成</span> <i class="fas fa-arrow-right"></i>
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- 底部说明 -->
    <footer class="border-t-4 border-black bg-primary py-12 px-6">
        <div class="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white border-2 border-black p-5 shadow-hard-sm hover:shadow-hard hover:-translate-y-1 transition-all">
                <div class="w-10 h-10 bg-secondary border-2 border-black flex items-center justify-center mb-3">
                    <i class="fas fa-bolt text-xl text-white drop-shadow-[1px_1px_0_#000]"></i>
                </div>
                <h3 class="font-black text-xl mb-2">极速秒开</h3>
                <p class="text-sm font-medium text-gray-700">优化到极致的跳转速度，就像闪电一样快，绝不浪费时间。</p>
            </div>
            
            <div class="bg-white border-2 border-black p-5 shadow-hard-sm hover:shadow-hard hover:-translate-y-1 transition-all">
                <div class="w-10 h-10 bg-accent border-2 border-black flex items-center justify-center mb-3">
                    <i class="fas fa-shield-halved text-xl text-black"></i>
                </div>
                <h3 class="font-black text-xl mb-2">安全第一</h3>
                <p class="text-sm font-medium text-gray-700">自动拦截恶意网站，为你的每一次点击保驾护航。</p>
            </div>
            
            <div class="bg-white border-2 border-black p-5 shadow-hard-sm hover:shadow-hard hover:-translate-y-1 transition-all">
                <div class="w-10 h-10 bg-orange-400 border-2 border-black flex items-center justify-center mb-3">
                    <i class="fas fa-chart-line text-xl text-white drop-shadow-[1px_1px_0_#000]"></i>
                </div>
                <h3 class="font-black text-xl mb-2">数据可视化</h3>
                <p class="text-sm font-medium text-gray-700">清晰直观的报表，看看谁点了你的链接，来自哪里。</p>
            </div>
        </div>
        
        <div class="text-center mt-12 font-bold text-black opacity-60">
            &copy; <?php echo $current_year; ?> 数果短链 · Made with <i class="fas fa-heart text-red-500 mx-1"></i> by You
        </div>
    </footer>

    <!-- 提示框 (Toast) -->
    <div id="toast" class="fixed top-8 left-1/2 transform -translate-x-1/2 bg-black text-white px-6 py-3 border-2 border-white shadow-[4px_4px_0_0_rgba(255,255,255,1)] flex items-center gap-3 transition-all duration-300 opacity-0 translate-y-[-100%] z-50 font-bold">
        <i class="fas fa-check text-green-400"></i>
        <span>复制成功!</span>
    </div>

    <script>
        // 自定义后缀切换
        const checkbox = document.getElementById('custom_enable');
        const customArea = document.getElementById('custom-area');
        const customInput = document.getElementById('custom_input');

        if(checkbox) {
            checkbox.addEventListener('change', function() {
                if(this.checked) {
                    customArea.classList.remove('max-h-0', 'opacity-0');
                    customArea.classList.add('max-h-32', 'opacity-100');
                    setTimeout(() => customInput.focus(), 100);
                } else {
                    customArea.classList.remove('max-h-32', 'opacity-100');
                    customArea.classList.add('max-h-0', 'opacity-0');
                }
            });
        }

        // 刷新验证码
        function refreshCaptcha() {
            const img = document.getElementById('captcha-img');
            const input = document.querySelector('input[name="captcha_answer"]');
            
            img.style.filter = 'blur(2px)';
            
            setTimeout(() => {
                img.src = 'captcha.php?t=' + new Date().getTime();
                img.onload = () => img.style.filter = 'none';
            }, 200);
            
            if(input) input.value = '';
        }

        // 复制功能
        function copyLink() {
            const linkText = document.getElementById('result-link').textContent.trim();
            const toast = document.getElementById('toast');
            
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(linkText).then(showToast);
            } else {
                const textArea = document.createElement("textarea");
                textArea.value = linkText;
                textArea.style.position = "fixed";
                textArea.style.opacity = 0;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                    showToast();
                } catch (err) {}
                document.body.removeChild(textArea);
            }
            
            function showToast() {
                toast.classList.remove('opacity-0', 'translate-y-[-100%]');
                setTimeout(() => {
                    toast.classList.add('opacity-0', 'translate-y-[-100%]');
                }, 2000);
            }
        }
    </script>
</body>
</html>