-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: dl
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_logs`
--

DROP TABLE IF EXISTS `access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(10) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `referer` varchar(500) DEFAULT NULL,
  `access_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_short_code` (`short_code`),
  KEY `idx_access_time` (`access_time`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_logs`
--

LOCK TABLES `access_logs` WRITE;
/*!40000 ALTER TABLE `access_logs` DISABLE KEYS */;
INSERT INTO `access_logs` VALUES (1,'0zUfpO','104.23.172.66','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.9.304 Mobile Safari/537.36','http://dl.sg.gy/','2025-12-01 05:16:56',NULL,NULL,'Mobile'),(2,'Idd5vJ','172.71.102.112','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.9.304 Mobile Safari/537.36','http://dl.sg.gy/admin.php?toggle_status=Idd5vJ&current=','2025-12-01 06:16:13',NULL,NULL,'Mobile'),(3,'0zUfpO','172.71.102.112','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.9.304 Mobile Safari/537.36','http://dl.sg.gy/admin.php?toggle_status=Idd5vJ&current=','2025-12-01 06:16:29',NULL,NULL,'Mobile'),(4,'Hk19vj','104.23.170.41','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.9.304 Mobile Safari/537.36','https://dl.sg.gy/','2025-12-01 07:07:26',NULL,NULL,'Mobile'),(5,'sct6MI','162.159.113.64','Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36','https://dl.sg.gy/','2025-12-01 07:18:36',NULL,NULL,'Mobile'),(6,'sct6MI','162.159.113.64','Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36','','2025-12-01 07:18:40',NULL,NULL,'Mobile'),(7,'sct6MI','162.159.113.64','Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36','','2025-12-01 07:18:50',NULL,NULL,'Mobile'),(8,'58PorE','104.23.251.165','Mozilla/5.0 (Linux; Android 16; PHK110 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-01 10:31:56',NULL,NULL,'Mobile'),(9,'I7lXX5','172.71.95.94','Mozilla/5.0 (Linux; Android 10; Mt论坛Lite) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.5563.15 Mobile Safari/537.36','','2025-12-01 20:25:31',NULL,NULL,'Mobile'),(10,'Bp83Xm','172.64.217.146','Mozilla/5.0 (Linux; Android 16; V2463A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.200 Mobile Safari/537.36 VivoBrowser/27.1.0.0','https://dl.sg.gy/','2025-12-02 00:09:51',NULL,NULL,'Mobile'),(11,'jOJpsT','108.162.246.90','Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36','','2025-12-02 01:04:43',NULL,NULL,'Mobile'),(12,'jOJpsT','162.159.113.64','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','http://dl.sg.gy/jOJpsT','2025-12-02 01:05:14',NULL,NULL,'Desktop'),(13,'jOJpsT','172.68.22.112','Mozilla/5.0 (Linux; Android 13; V2314DA Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/121.0.6167.71 MQQBrowser/6.2 TBS/047921 Mobile Safari/537.36 V1_AND_SQ_9.1.97_10800_YYB_D QQ/9.1.97.27900 NetType/4G WebP/0.3.0 AppId/537301752 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/1 QQTheme/2921 StudyMode/0 CurrentMode/1 CurrentFontScale/1.0 GlobalDensityScale/0.90000004 AllowLandscape/false InMagicWin/0','','2025-12-02 01:05:15',NULL,NULL,'Mobile'),(14,'kXpXh8','162.159.113.65','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.11.301 Mobile Safari/537.36','https://dl.sg.gy/admin.php','2025-12-02 06:32:11',NULL,NULL,'Mobile'),(15,'I7lXX5','162.159.113.65','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.11.301 Mobile Safari/537.36','https://dl.sg.gy/admin.php','2025-12-02 06:32:44',NULL,NULL,'Mobile'),(16,'Bp83Xm','172.71.95.93','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.11.301 Mobile Safari/537.36','https://dl.sg.gy/admin.php','2025-12-02 06:35:51',NULL,NULL,'Mobile'),(17,'jOJpsT','172.71.95.93','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.11.301 Mobile Safari/537.36','https://dl.sg.gy/admin.php','2025-12-02 06:36:02',NULL,NULL,'Mobile'),(18,'kXpXh8','162.158.186.26','Mozilla/5.0 (Linux; Android 11; CPH2185) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Mobile Safari/537.36','','2025-12-02 06:40:14',NULL,NULL,'Mobile'),(19,'jOJpsT','104.23.251.164','Mozilla/5.0 (Linux; Android 11; CPH2185) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Mobile Safari/537.36','','2025-12-02 06:40:45',NULL,NULL,'Mobile'),(20,'QiFP7r','172.69.34.113','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-02 08:47:29',NULL,NULL,'Mobile'),(21,'QiFP7r','162.158.91.60','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-02 08:47:31',NULL,NULL,'Mobile'),(22,'I7lXX5','172.64.217.146','Mozilla/5.0 (Linux; Android 11; V2055A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Mobile Safari/537.36','','2025-12-02 17:55:06',NULL,NULL,'Mobile'),(23,'111','172.71.24.135','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0','https://dl.sg.gy/','2025-12-07 09:24:10',NULL,NULL,'Desktop'),(24,'111','172.71.24.135','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0','https://dl.sg.gy/','2025-12-07 09:24:10',NULL,NULL,'Desktop'),(25,'111','172.71.24.135','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0','https://dl.sg.gy/','2025-12-07 09:24:17',NULL,NULL,'Desktop'),(26,'111','172.71.24.135','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0','https://dl.sg.gy/','2025-12-07 09:24:17',NULL,NULL,'Desktop'),(27,'ggs','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:34:54',NULL,NULL,'Mobile'),(28,'ggs','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:34:54',NULL,NULL,'Mobile'),(29,'ggs','162.158.187.5','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:34:56',NULL,NULL,'Mobile'),(30,'ggs','162.158.187.5','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:34:56',NULL,NULL,'Mobile'),(31,'ddm','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:00',NULL,NULL,'Mobile'),(32,'ddm','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:00',NULL,NULL,'Mobile'),(33,'ddm','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:02',NULL,NULL,'Mobile'),(34,'ddm','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:02',NULL,NULL,'Mobile'),(35,'ddm','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:17',NULL,NULL,'Mobile'),(36,'ddm','172.70.215.71','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:17',NULL,NULL,'Mobile'),(37,'ddm','162.158.91.57','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:19',NULL,NULL,'Mobile'),(38,'ddm','162.158.91.57','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:37:19',NULL,NULL,'Mobile'),(39,'ddm','104.23.251.164','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:47:25',NULL,NULL,'Mobile'),(40,'ddm','104.23.251.164','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:47:25',NULL,NULL,'Mobile'),(41,'ddm','104.23.251.164','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:47:28',NULL,NULL,'Mobile'),(42,'ddm','104.23.251.164','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:47:28',NULL,NULL,'Mobile'),(43,'ddm','172.69.33.201','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:56:14',NULL,NULL,'Mobile'),(44,'ddm','172.69.33.201','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:56:14',NULL,NULL,'Mobile'),(45,'ddm','172.64.217.146','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:56:17',NULL,NULL,'Mobile'),(46,'ddm','172.64.217.146','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 09:56:17',NULL,NULL,'Mobile'),(47,'ddm','104.23.251.164','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 10:31:24',NULL,NULL,'Mobile'),(48,'ddm','104.23.251.164','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 10:31:24',NULL,NULL,'Mobile'),(49,'ddm','162.158.91.57','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 10:31:26',NULL,NULL,'Mobile'),(50,'ddm','162.158.91.57','Mozilla/5.0 (Linux; Android 15; RMX3700 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/142.0.7444.102 Mobile Safari/537.36','','2025-12-07 10:31:26',NULL,NULL,'Mobile'),(51,'C8bG48','172.71.146.245','Mozilla/5.0 (Linux; Android 14; PGGM10 Build/UKQ1.230924.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.124 Mobile Safari/537.36','','2025-12-07 21:43:23',NULL,NULL,'Mobile'),(52,'C8bG48','172.71.146.245','Mozilla/5.0 (Linux; Android 14; PGGM10 Build/UKQ1.230924.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7390.124 Mobile Safari/537.36','','2025-12-07 21:43:23',NULL,NULL,'Mobile'),(53,'qk666-','162.158.178.107','Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36','','2025-12-08 05:51:38',NULL,NULL,'Mobile'),(54,'qk666-','162.158.178.107','Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36','','2025-12-08 05:51:38',NULL,NULL,'Mobile');
/*!40000 ALTER TABLE `access_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `short_url_access_log`
--

DROP TABLE IF EXISTS `short_url_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `short_url_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(10) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `referer` text,
  `country` varchar(100) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `access_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_short_code` (`short_code`),
  KEY `idx_access_time` (`access_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `short_url_access_log`
--

LOCK TABLES `short_url_access_log` WRITE;
/*!40000 ALTER TABLE `short_url_access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `short_url_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `short_url_device_stats`
--

DROP TABLE IF EXISTS `short_url_device_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `short_url_device_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(10) NOT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `access_count` int(11) DEFAULT '0',
  `last_accessed` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_device` (`short_code`,`device_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `short_url_device_stats`
--

LOCK TABLES `short_url_device_stats` WRITE;
/*!40000 ALTER TABLE `short_url_device_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `short_url_device_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `short_urls`
--

DROP TABLE IF EXISTS `short_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `short_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `long_url` varchar(1000) NOT NULL,
  `short_code` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `clicks` int(11) DEFAULT '0',
  `unique_visitors` int(11) DEFAULT '0',
  `last_accessed` timestamp NULL DEFAULT NULL,
  `title` varchar(255) DEFAULT '',
  `is_active` tinyint(4) DEFAULT '1',
  `expiry_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_code` (`short_code`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `short_urls`
--

LOCK TABLES `short_urls` WRITE;
/*!40000 ALTER TABLE `short_urls` DISABLE KEYS */;
INSERT INTO `short_urls` VALUES (1,'https://baidu.com','jagFObY','2025-11-28 10:10:19',0,0,NULL,'',1,NULL),(2,'https://www.baidu.com','test','2025-11-28 10:26:04',0,0,NULL,'',1,NULL),(3,'https://ppyzz.lanzouo.com/tvtg','oQ7XGB','2025-11-28 10:42:57',1,0,NULL,'',1,NULL),(4,'https://ppyzz.lanzouo.com/tvtg','DHIGJd','2025-11-28 10:53:06',0,0,NULL,'',1,NULL),(5,'https://ppyzz.lanzouo.com/tvtg','1GxZFl','2025-11-28 12:02:24',0,0,NULL,'',1,NULL),(6,'https://ppyzz.lanzouo.com/tvtg','AMb2q3','2025-11-28 12:02:30',0,0,NULL,'',1,NULL),(7,'https://ppyzz.lanzouo.com/tvtg','2UuuH9','2025-11-28 13:10:39',1,0,NULL,'',1,NULL),(8,'https://ppyzz.lanzouo.com/tvtg','3glJ32','2025-11-29 08:49:25',1,0,NULL,'',1,NULL),(9,'https://vedl.lxapp3.shop/hkan/01/dl.html?cId=d8238','qaZHsM','2025-11-29 14:24:37',1,0,NULL,'',1,NULL),(10,'https://ppyzz.lanzouo.com/tvtg','tmLqOh','2025-11-30 07:59:56',1,0,NULL,'',1,NULL),(11,'https://ppyzz.lanzouo.com/tvtg','wisN6j','2025-11-30 08:56:58',0,0,NULL,'',1,NULL),(12,'https://ppyzz.lanzouo.com/tvtg','0zUfpO','2025-12-01 05:16:50',4,2,'2025-12-01 06:16:29','',1,NULL),(13,'https://baidu0com','1MwyoB','2025-12-01 05:18:56',0,0,NULL,'',1,NULL),(15,'https://ppyzz.lanzouo.com/tvtg','Jj4FRg','2025-12-01 06:19:02',0,0,NULL,'',1,NULL),(16,'https://ppyzz.lanzouo.com/tvtg','HrqSFf','2025-12-01 06:19:47',0,0,NULL,'',1,NULL),(17,'https://ppyzz.lanzouo.com/tvtg','GVM7W9','2025-12-01 06:32:26',0,0,NULL,'',1,NULL),(18,'https://q.axvo.cn/f/qGjiV/%E6%95%B0%E6%9E%9C%E7%9F%AD%E9%93%BE.zip','rW4j4n','2025-12-01 07:05:42',0,0,NULL,'',1,NULL),(19,'https://qq.com','Hk19vj','2025-12-01 07:06:46',2,1,'2025-12-01 07:07:26','',1,NULL),(20,'https://dwz.cn','sct6MI','2025-12-01 07:18:33',6,1,'2025-12-01 07:18:50','',1,NULL),(21,'http://dl.141991.xyz','kXpXh8','2025-12-01 09:38:00',4,2,'2025-12-02 06:40:14','',1,NULL),(22,'https://dl.sg.gy/','58PorE','2025-12-01 10:31:40',2,1,'2025-12-01 10:31:56','',1,NULL),(23,'http://www.94ali.top','I7lXX5','2025-12-01 20:25:11',6,3,'2025-12-02 17:55:06','',1,NULL),(24,'https://ps.ssl.qhimg.com/t029e039aa6fb77ee2e.jpg','Bp83Xm','2025-12-02 00:09:44',4,2,'2025-12-02 06:35:51','',1,NULL),(25,'https://126261.xyz/','jOJpsT','2025-12-02 01:04:31',10,5,'2025-12-02 06:40:45','',1,NULL),(26,'https://www.baidu.com','QiFP7r','2025-12-02 08:47:04',4,2,'2025-12-02 08:47:31','',1,NULL),(27,'https://example.com/trace-test-1764754651','eF4536','2025-12-03 09:37:31',0,0,NULL,'',1,NULL),(28,'https://example.com/trace-test-1764848674','Px4wMq','2025-12-04 11:44:35',0,0,NULL,'',1,NULL),(29,'https://baidu.com','wk77Sv','2025-12-07 09:15:56',0,0,NULL,'',1,NULL),(30,'https://baidu.com','111','2025-12-07 09:16:17',6,1,'2025-12-07 09:24:17','',1,NULL),(31,'https://www.baidu.com','ggs','2025-12-07 09:34:40',6,2,'2025-12-07 09:34:56','',1,NULL),(32,'https://www.baidu.com','ddm','2025-12-07 09:36:44',24,5,'2025-12-07 10:31:26','',1,NULL),(33,'https://jsfiddle.net/p2nhg4uj/1/','C8bG48','2025-12-07 21:42:23',2,1,'2025-12-07 21:43:23','',1,NULL),(34,'https://www.123912.com/s/4Sc0Vv-58o0v','qk666-','2025-12-08 05:51:29',2,1,'2025-12-08 05:51:38','',1,NULL);
/*!40000 ALTER TABLE `short_urls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dl'
--

--
-- Dumping routines for database 'dl'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08 14:03:39
