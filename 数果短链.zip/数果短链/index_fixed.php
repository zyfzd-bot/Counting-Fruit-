<?php
// index_fixed.php - 修复后的短链系统主页面
session_start();

// 确保包含正确的functions.php
$func_path = __DIR__ . '/includes/functions.php';
if (!file_exists($func_path)) {
    // 尝试在根目录查找
    $func_path = __DIR__ . '/functions.php';
}

if (!file_exists($func_path) || !is_readable($func_path)) {
    die("<h1>系统错误</h1>
        <p>无法找到或读取 functions.php 文件。</p>
        <p>请确保文件存在且权限正确（644）。</p>
        <p>尝试查找的位置：</p>
        <ul>
            <li>" . __DIR__ . "/includes/functions.php</li>
            <li>" . __DIR__ . "/functions.php</li>
        </ul>
        <p><a href='check_include.php'>运行诊断脚本</a></p>");
}

require_once $func_path;

$short_url = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $long_url = $_POST['long_url'] ?? '';
    $captcha_answer = $_POST['captcha_answer'] ?? '';
    $custom_enable = isset($_POST['custom_enable']) ? true : false;
    $custom_url = $_POST['custom_url'] ?? '';
    
    if (empty($captcha_answer) || !validate_captcha($captcha_answer)) {
        $error = "验证码错误或已过期，请重新输入";
    } elseif (empty($long_url)) {
        $error = "请输入URL地址";
    } else {
        if (validate_url($long_url)) {
            // 如果有自定义短链
            if ($custom_enable && !empty($custom_url)) {
                $short_code = create_short_url($long_url, $custom_url);
                
                if ($short_code === 'invalid_format') {
                    $error = "自定义短链格式无效！只能包含字母、数字、下划线和连字符，长度3-20位";
                } elseif ($short_code === 'already_exists') {
                    $error = "自定义短链已被使用，请换一个";
                } elseif ($short_code) {
                    $short_url = BASE_URL . '/' . $short_code;
                } else {
                    $error = "生成短链接失败，请重试";
                }
            } else {
                // 使用随机短链
                $short_code = create_short_url($long_url);
                if ($short_code) {
                    $short_url = BASE_URL . '/' . $short_code;
                } else {
                    $error = "生成短链接失败，请重试";
                }
            }
        } else {
            $error = "请输入有效的URL地址";
        }
    }
}

$current_year = date('Y');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数果在线网址缩短 - 安全可靠的短链接服务</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
        }

        :root {
            --primary: #4361ee;
            --secondary: #3a0ca3;
            --accent: #7209b7;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #4cc9f0;
            --warning: #f72585;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            text-align: center;
            padding: 40px 20px;
            color: white;
        }

        header h1 {
            font-size: 2.8rem;
            margin-bottom: 15px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        header p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
            opacity: 0.9;
        }

        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .url-form {
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
        }

        .input-group {
            display: flex;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
        }

        .input-icon {
            background: var(--light-gray);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            color: var(--gray);
        }

        .form-control {
            flex: 1;
            border: none;
            padding: 15px 20px;
            font-size: 1rem;
            outline: none;
            background: white;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            cursor: pointer;
        }

        .checkbox-group input {
            margin-right: 10px;
            cursor: pointer;
        }

        .custom-url {
            margin-top: 15px;
            animation: fadeIn 0.3s ease;
        }

        .btn {
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 15px 30px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn:hover {
            background: var(--secondary);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(67, 97, 238, 0.3);
        }

        .btn-block {
            display: block;
            width: 100%;
            justify-content: center;
        }

        .captcha-section {
            background: var(--light-gray);
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }

        .captcha-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .captcha-image {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #captcha-img {
            border: 2px solid #e1e8ed;
            border-radius: 8px;
            padding: 5px;
            background: white;
            cursor: pointer;
            transition: all 0.3s ease;
            height: 50px;
        }

        #captcha-img:hover {
            border-color: var(--primary);
            transform: scale(1.05);
        }

        .refresh-btn {
            background: var(--gray);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 10px 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.9rem;
        }

        .refresh-btn:hover {
            background: #5a6268;
            transform: translateY(-1px);
        }

        .captcha-input {
            flex: 1;
        }

        .captcha-input input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e8ed;
            border-radius: 8px;
            font-size: 16px;
            text-align: center;
            letter-spacing: 3px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .captcha-input input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
            outline: none;
        }

        .captcha-tip {
            text-align: center;
            color: var(--gray);
            font-size: 12px;
            margin-top: 8px;
            font-style: italic;
        }

        .error-message {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #c33;
            margin: 20px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .success-result {
            background: #e8f5e8;
            color: #2d5a2d;
            padding: 25px;
            border-radius: 12px;
            border-left: 4px solid #4caf50;
            margin: 20px 0;
        }

        .result-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .short-url-container {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }

        .short-url {
            flex: 1;
            background: white;
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #4caf50;
            color: #2d5a2d;
            text-decoration: none;
            font-weight: 600;
            word-break: break-all;
            transition: all 0.3s ease;
        }

        .short-url:hover {
            background: #4caf50;
            color: white;
            text-decoration: none;
        }

        .copy-btn {
            background: #4caf50;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: 600;
        }

        .copy-btn:hover {
            background: #45a049;
            transform: translateY(-1px);
        }

        .stats-link {
            background: #e3f2fd;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
        }

        .stats-link p {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .stats-link a {
            color: #1976d2;
            text-decoration: none;
            font-weight: 600;
        }

        .stats-link a:hover {
            text-decoration: underline;
        }

        .features-section {
            padding: 40px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .section-title {
            text-align: center;
            margin-bottom: 40px;
            color: var(--dark);
            font-size: 2rem;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .feature-card {
            text-align: center;
            padding: 30px 20px;
            border-radius: 12px;
            background: var(--light);
            transition: all 0.3s ease;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .feature-icon {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 20px;
        }

        .feature-title {
            font-size: 1.4rem;
            margin-bottom: 15px;
            color: var(--dark);
        }

        .feature-desc {
            color: var(--gray);
            line-height: 1.6;
        }

        .faq-section {
            padding: 40px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .faq-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
        }

        .faq-item {
            padding: 20px;
            border-radius: 10px;
            background: var(--light);
        }

        .faq-question {
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .faq-answer {
            color: var(--gray);
            line-height: 1.6;
        }

        .footer {
            text-align: center;
            padding: 30px 20px;
            color: white;
        }

        .copyright {
            font-weight: 600;
            margin-bottom: 10px;
        }

        .url-preview {
            display: flex;
            align-items: center;
            margin-top: 10px;
            padding: 10px;
            background: var(--light);
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .url-preview .domain {
            color: var(--primary);
            font-weight: bold;
        }

        .url-preview .custom-part {
            color: var(--accent);
            font-weight: bold;
        }

        .url-hint {
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 5px;
            font-style: italic;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 2rem;
            }

            .url-form {
                padding: 25px;
            }

            .features-section, .faq-section {
                padding: 25px;
            }

            .features-grid, .faq-grid {
                grid-template-columns: 1fr;
            }

            .captcha-group {
                flex-direction: column;
            }

            .short-url-container {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>数果在线网址缩短 - 修复版</h1>
            <p>将长网址转换为短网址，支持自定义短链、二维码生成（开发中）、访问统计，提升分享体验</p>
        </header>

        <div class="card">
            <div class="url-form">
                <h2 style="margin-bottom: 20px; color: var(--dark);">生成短链</h2>
                
                <form method="POST" id="url-form">
                    <div class="form-group">
                        <label for="long_url">输入您的长网址</label>
                        <div class="input-group">
                            <div class="input-icon">
                                <i class="fas fa-link"></i>
                            </div>
                            <input type="url" name="long_url" id="long_url" class="form-control" 
                                   placeholder="https://www.example.com/very-long-url-path" 
                                   required value="<?php echo isset($_POST['long_url']) ? htmlspecialchars($_POST['long_url']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="checkbox-group">
                        <input type="checkbox" id="custom_enable" name="custom_enable" 
                               <?php echo isset($_POST['custom_enable']) ? 'checked' : ''; ?>>
                        <label for="custom_enable">自定义短链（可选）</label>
                    </div>
                    
                    <div class="custom-url" id="custom_url_container" 
                         style="<?php echo (isset($_POST['custom_enable']) || !empty($_POST['custom_url'])) ? 'display: block;' : 'display: none;' ?>">
                        <div class="input-group">
                            <div class="input-icon">
                                <i class="fas fa-pen"></i>
                            </div>
                            <input type="text" name="custom_url" id="custom_url" class="form-control" 
                                   placeholder="输入自定义短链代码 (字母、数字、下划线、连字符，3-20位)"
                                   value="<?php echo isset($_POST['custom_url']) ? htmlspecialchars($_POST['custom_url']) : ''; ?>">
                        </div>
                        <div class="url-hint" id="url-hint">
                            例如：my-link, product-2024, best_deal
                        </div>
                        <div class="url-preview" id="url-preview" style="display: none;">
                            <span class="domain"><?php echo BASE_URL; ?>/</span><span class="custom-part" id="preview-code"></span>
                        </div>
                    </div>
                    
                    <div class="captcha-section">
                        <div class="captcha-group">
                            <div class="captcha-image">
                                <img src="captcha.php?t=<?php echo time(); ?>" alt="验证码" id="captcha-img" title="点击刷新验证码">
                                <button type="button" class="refresh-btn" onclick="refreshCaptcha()">
                                    <i class="fas fa-redo"></i> 换一张
                                </button>
                            </div>
                            <div class="captcha-input">
                                <input type="text" name="captcha_answer" placeholder="请输入验证码" required maxlength="4" 
                                       value="<?php echo isset($_POST['captcha_answer']) ? htmlspecialchars($_POST['captcha_answer']) : ''; ?>">
                                <div class="captcha-tip">验证码只有一分钟有效期哦</div>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-block">
                        <i class="fas fa-magic"></i> 生成短链
                    </button>
                </form>

                <?php if (isset($error) && !empty($error)): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($short_url) && !empty($short_url)): ?>
                    <div class="success-result">
                        <div class="result-header">
                            <i class="fas fa-check-circle"></i>
                            <span>短链接已生成!</span>
                        </div>
                        <div class="short-url-container">
                            <a href="<?php echo htmlspecialchars($short_url); ?>" class="short-url" id="short-url" target="_blank">
                                <?php echo htmlspecialchars($short_url); ?>
                            </a>
                            <button class="copy-btn" id="copy-btn">
                                <i class="fas fa-copy"></i> 复制
                            </button>
                        </div>
                        <p><i class="fas fa-info-circle"></i> 点击链接测试或复制分享给他人</p>
                        
                        <div class="stats-link">
                            <p>
                                <i class="fas fa-chart-line" style="color: #1976d2;"></i>
                                <a href="stats.php?code=<?php echo isset($short_code) ? $short_code : ''; ?>" target="_blank">
                                    查看实时统计
                                </a>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="features-section">
            <h2 class="section-title">功能特色</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3 class="feature-title">快速生成</h3>
                    <p class="feature-desc">一键生成短链接，操作简单便捷，毫秒级响应速度</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3 class="feature-title">安全可靠</h3>
                    <p class="feature-desc">采用先进加密技术，保障链接安全，防止恶意攻击</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <h3 class="feature-title">二维码支持（开发中）</h3>
                    <p class="feature-desc">自动生成二维码，方便移动端分享，支持高清下载</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-edit"></i>
                    </div>
                    <h3 class="feature-title">自定义短链</h3>
                    <p class="feature-desc">支持自定义短链接后缀，创建易记的个性化链接</p>
                </div>
            </div>
        </div>

        <div class="faq-section">
            <h2 class="section-title">常见问题</h2>
            <div class="faq-grid">
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="fas fa-question-circle" style="color: var(--primary);"></i>
                        <span>短链接会永久有效吗？</span>
                    </div>
                    <div class="faq-answer">
                        是的，我们生成的短链接默认永久有效，除非您主动删除或系统维护需要。
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="fas fa-question-circle" style="color: var(--primary);"></i>
                        <span>可以自定义短链接吗？</span>
                    </div>
                    <div class="faq-answer">
                        是的！现在支持自定义短链接后缀，您可以创建易记的个性化链接，如：dl.sg.gy/my-brand
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="fas fa-question-circle" style="color: var(--primary);"></i>
                        <span>短链接生成是免费的吗？</span>
                    </div>
                    <div class="faq-answer">
                        完全免费！我们的短链接服务对所有用户免费开放，没有任何隐藏费用。
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <i class="fas fa-question-circle" style="color: var(--primary);"></i>
                        <span>短链接安全吗？</span>
                    </div>
                    <div class="faq-answer">
                        我们采用多重安全措施，包括验证码防护、链接加密和恶意链接检测，确保您的链接安全。
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <p class="copyright">&copy; <?php echo $current_year; ?> 数果在线网址缩短服务 - 修复版 - 保留所有权利</p>
            <p>让链接分享更简单、更便捷</p>
        </div>
    </div>

    <script>
        // 自定义短链显示/隐藏
        const customEnableCheckbox = document.getElementById('custom_enable');
        const customUrlContainer = document.getElementById('custom_url_container');
        const customUrlInput = document.getElementById('custom_url');
        const urlPreview = document.getElementById('url-preview');
        const previewCode = document.getElementById('preview-code');
        const urlHint = document.getElementById('url-hint');

        customEnableCheckbox.addEventListener('change', function() {
            if (this.checked) {
                customUrlContainer.style.display = 'block';
                customUrlInput.focus();
            } else {
                customUrlContainer.style.display = 'none';
                urlPreview.style.display = 'none';
            }
        });

        // 实时预览自定义短链
        customUrlInput.addEventListener('input', function() {
            const value = this.value.trim();
            
            if (value.length > 0) {
                previewCode.textContent = value;
                urlPreview.style.display = 'flex';
                urlHint.style.display = 'none';
                
                // 验证输入格式
                const isValid = /^[a-zA-Z0-9_-]{3,20}$/.test(value);
                if (isValid) {
                    previewCode.style.color = '#7209b7';
                } else {
                    previewCode.style.color = '#f72585';
                }
            } else {
                urlPreview.style.display = 'none';
                urlHint.style.display = 'block';
            }
        });

        // 表单验证
        document.getElementById('url-form').addEventListener('submit', function(e) {
            const customEnable = document.getElementById('custom_enable').checked;
            const customUrl = document.getElementById('custom_url').value.trim();
            
            if (customEnable && customUrl) {
                // 验证自定义短链格式
                const isValid = /^[a-zA-Z0-9_-]{3,20}$/.test(customUrl);
                if (!isValid) {
                    e.preventDefault();
                    alert('自定义短链格式无效！\n只能包含字母、数字、下划线和连字符\n长度3-20个字符');
                    customUrlInput.focus();
                    return false;
                }
                
                // 检查是否包含保留字（可选）
                const reservedWords = ['admin', 'login', 'register', 'api', 'static', 'images', 'css', 'js'];
                if (reservedWords.includes(customUrl.toLowerCase())) {
                    if (!confirm('这个短链可能和系统功能冲突，确定要使用吗？')) {
                        e.preventDefault();
                        return false;
                    }
                }
            }
        });

        // 复制功能
        document.getElementById('copy-btn')?.addEventListener('click', function() {
            const shortUrl = document.getElementById('short-url').textContent;
            
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(shortUrl).then(function() {
                    showNotification('短链接已复制到剪贴板', 'success');
                }).catch(function() {
                    fallbackCopy(shortUrl);
                });
            } else {
                fallbackCopy(shortUrl);
            }
        });

        // 降级复制方案
        function fallbackCopy(text) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.opacity = '0';
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                showNotification('短链接已复制到剪贴板', 'success');
            } catch (err) {
                showNotification('复制失败，请手动复制链接', 'error');
            }
            document.body.removeChild(textArea);
        }

        // 显示通知
        function showNotification(message, type) {
            const existingNotification = document.querySelector('.notification');
            if (existingNotification) {
                existingNotification.remove();
            }
            
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}-circle"></i>
                ${message}
            `;
            
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#4caf50' : '#f44336'};
                color: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                z-index: 1000;
                display: flex;
                align-items: center;
                gap: 10px;
                animation: slideIn 0.3s ease;
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 3000);
        }

        // 刷新验证码
        function refreshCaptcha() {
            const captchaImg = document.getElementById('captcha-img');
            const captchaInput = document.querySelector('input[name="captcha_answer"]');
            
            captchaImg.src = 'captcha.php?t=' + new Date().getTime();
            
            if (captchaInput) {
                captchaInput.value = '';
                captchaInput.focus();
            }
        }

        // 点击验证码图片也可刷新
        document.getElementById('captcha-img').addEventListener('click', refreshCaptcha);

        // 添加CSS动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
        
        // 页面加载时检查functions.php是否加载成功
        window.addEventListener('load', function() {
            console.log('index_fixed.php 已加载');
            
            // 如果有短链生成失败的错误，可能是数据库问题
            const errorElement = document.querySelector('.error-message');
            if (errorElement && errorElement.textContent.includes('生成短链接失败')) {
                console.log('检测到短链生成失败错误，可能是数据库连接问题');
            }
        });
    </script>
</body>
</html>