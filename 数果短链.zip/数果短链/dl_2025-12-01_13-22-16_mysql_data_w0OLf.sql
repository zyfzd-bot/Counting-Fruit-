-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: dl
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_logs`
--

DROP TABLE IF EXISTS `access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(10) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `referer` varchar(500) DEFAULT NULL,
  `access_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_short_code` (`short_code`),
  KEY `idx_access_time` (`access_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_logs`
--

LOCK TABLES `access_logs` WRITE;
/*!40000 ALTER TABLE `access_logs` DISABLE KEYS */;
INSERT INTO `access_logs` VALUES (1,'0zUfpO','104.23.172.66','Mozilla/5.0 (Linux; Android 12; HarmonyOS; CTR-AL20; HMSCore 6.15.4.322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/16.0.9.304 Mobile Safari/537.36','http://dl.sg.gy/','2025-12-01 05:16:56',NULL,NULL,'Mobile');
/*!40000 ALTER TABLE `access_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `short_url_access_log`
--

DROP TABLE IF EXISTS `short_url_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `short_url_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(10) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `referer` text,
  `country` varchar(100) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `browser` varchar(100) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `access_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_short_code` (`short_code`),
  KEY `idx_access_time` (`access_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `short_url_access_log`
--

LOCK TABLES `short_url_access_log` WRITE;
/*!40000 ALTER TABLE `short_url_access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `short_url_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `short_url_device_stats`
--

DROP TABLE IF EXISTS `short_url_device_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `short_url_device_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_code` varchar(10) NOT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `access_count` int(11) DEFAULT '0',
  `last_accessed` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_device` (`short_code`,`device_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `short_url_device_stats`
--

LOCK TABLES `short_url_device_stats` WRITE;
/*!40000 ALTER TABLE `short_url_device_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `short_url_device_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `short_urls`
--

DROP TABLE IF EXISTS `short_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `short_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `long_url` varchar(1000) NOT NULL,
  `short_code` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `clicks` int(11) DEFAULT '0',
  `unique_visitors` int(11) DEFAULT '0',
  `last_accessed` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_code` (`short_code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `short_urls`
--

LOCK TABLES `short_urls` WRITE;
/*!40000 ALTER TABLE `short_urls` DISABLE KEYS */;
INSERT INTO `short_urls` VALUES (1,'https://baidu.com','jagFObY','2025-11-28 10:10:19',0,0,NULL),(2,'https://www.baidu.com','test','2025-11-28 10:26:04',0,0,NULL),(3,'https://ppyzz.lanzouo.com/tvtg','oQ7XGB','2025-11-28 10:42:57',1,0,NULL),(4,'https://ppyzz.lanzouo.com/tvtg','DHIGJd','2025-11-28 10:53:06',0,0,NULL),(5,'https://ppyzz.lanzouo.com/tvtg','1GxZFl','2025-11-28 12:02:24',0,0,NULL),(6,'https://ppyzz.lanzouo.com/tvtg','AMb2q3','2025-11-28 12:02:30',0,0,NULL),(7,'https://ppyzz.lanzouo.com/tvtg','2UuuH9','2025-11-28 13:10:39',1,0,NULL),(8,'https://ppyzz.lanzouo.com/tvtg','3glJ32','2025-11-29 08:49:25',1,0,NULL),(9,'https://vedl.lxapp3.shop/hkan/01/dl.html?cId=d8238','qaZHsM','2025-11-29 14:24:37',1,0,NULL),(10,'https://ppyzz.lanzouo.com/tvtg','tmLqOh','2025-11-30 07:59:56',1,0,NULL),(11,'https://ppyzz.lanzouo.com/tvtg','wisN6j','2025-11-30 08:56:58',0,0,NULL),(12,'https://ppyzz.lanzouo.com/tvtg','0zUfpO','2025-12-01 05:16:50',2,1,'2025-12-01 05:16:56'),(13,'https://baidu0com','1MwyoB','2025-12-01 05:18:56',0,0,NULL),(14,'https://baidu0com','Idd5vJ','2025-12-01 05:20:04',0,0,NULL);
/*!40000 ALTER TABLE `short_urls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dl'
--

--
-- Dumping routines for database 'dl'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 13:22:16
