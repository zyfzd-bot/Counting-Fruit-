<?php
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 检查是否提供了短代码
$short_code = $_GET['code'] ?? '';
$stats = null;

if (!empty($short_code)) {
    $stats = get_url_stats($short_code);
    if (!$stats) {
        header("Location: " . BASE_URL . "?error=短链接不存在");
        exit;
    }
}

$current_year = date('Y');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>链接统计 - 数果短链</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 2.5em;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #6c757d;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card i {
            font-size: 2.5em;
            color: #4facfe;
            margin-bottom: 15px;
        }

        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #2c3e50;
            margin: 10px 0;
        }

        .stat-label {
            color: #6c757d;
            font-size: 1.1em;
        }

        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .chart-title {
            color: #2c3e50;
            margin-bottom: 20px;
            text-align: center;
            font-size: 1.5em;
        }

        .url-info {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .url-info h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            border-bottom: 2px solid #f8f9fa;
            padding-bottom: 10px;
        }

        .url-info p {
            margin-bottom: 10px;
        }

        .original-url {
            word-break: break-all;
            color: #6c757d;
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
        }

        .recent-access {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .access-list {
            max-height: 400px;
            overflow-y: auto;
        }

        .access-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
        }

        .access-item:last-child {
            border-bottom: none;
        }

        .access-info {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .access-time {
            color: #6c757d;
            font-size: 0.9em;
        }

        .access-details {
            display: flex;
            gap: 15px;
            font-size: 0.9em;
            color: #6c757d;
        }

        .no-data {
            text-align: center;
            color: #6c757d;
            padding: 40px;
            font-style: italic;
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .access-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .access-details {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-chart-line"></i> 链接统计</h1>
            <a href="admin.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> 返回管理面板
            </a>
        </div>

        <?php if ($stats): ?>
            <!-- 链接信息 -->
            <div class="url-info">
                <h3>链接信息</h3>
                <p><strong>短链接:</strong> <?php echo BASE_URL . '/' . $stats['short_code']; ?></p>
                <p><strong>原链接:</strong> 
                    <div class="original-url"><?php echo htmlspecialchars($stats['long_url']); ?></div>
                </p>
                <p><strong>创建时间:</strong> <?php echo date('Y-m-d H:i:s', strtotime($stats['created_at'])); ?></p>
                <?php if (isset($stats['last_accessed']) && $stats['last_accessed']): ?>
                    <p><strong>最后访问:</strong> <?php echo date('Y-m-d H:i:s', strtotime($stats['last_accessed'])); ?></p>
                <?php endif; ?>
            </div>

            <!-- 统计卡片 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <i class="fas fa-mouse-pointer"></i>
                    <div class="stat-number"><?php echo isset($stats['clicks']) ? $stats['clicks'] : 0; ?></div>
                    <div class="stat-label">总点击次数</div>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-users"></i>
                    <div class="stat-number"><?php echo isset($stats['unique_visitors']) ? $stats['unique_visitors'] : 0; ?></div>
                    <div class="stat-label">独立访客</div>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-calendar-day"></i>
                    <div class="stat-number"><?php echo isset($stats['recent_access']) ? count($stats['recent_access']) : 0; ?></div>
                    <div class="stat-label">最近访问记录</div>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-chart-pie"></i>
                    <div class="stat-number"><?php echo isset($stats['device_distribution']) ? count($stats['device_distribution']) : 0; ?></div>
                    <div class="stat-label">设备类型</div>
                </div>
            </div>

            <!-- 点击趋势图表 -->
            <div class="chart-container">
                <div class="chart-title">24小时点击趋势</div>
                <canvas id="clickChart" height="100"></canvas>
            </div>

            <!-- 设备分布图表 -->
            <div class="chart-container">
                <div class="chart-title">设备分布</div>
                <canvas id="deviceChart" height="100"></canvas>
            </div>

            <!-- 浏览器分布图表 -->
            <div class="chart-container">
                <div class="chart-title">浏览器分布</div>
                <canvas id="browserChart" height="100"></canvas>
            </div>

            <!-- 最近访问记录 -->
            <div class="recent-access">
                <div class="chart-title">最近访问记录</div>
                <div class="access-list">
                    <?php if (isset($stats['recent_access']) && !empty($stats['recent_access'])): ?>
                        <?php foreach ($stats['recent_access'] as $access): ?>
                            <div class="access-item">
                                <div class="access-info">
                                    <div class="access-time">
                                        <?php echo date('Y-m-d H:i:s', strtotime($access['access_time'])); ?>
                                    </div>
                                    <div class="access-details">
                                        <span><i class="fas fa-desktop"></i> <?php echo $access['device_type']; ?></span>
                                        <span><i class="fas fa-globe"></i> <?php echo $access['browser']; ?></span>
                                        <span><i class="fas fa-map-marker-alt"></i> <?php echo $access['ip_address']; ?></span>
                                        <?php if ($access['referer']): ?>
                                            <span><i class="fas fa-external-link-alt"></i> <?php echo htmlspecialchars(substr($access['referer'], 0, 50)); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-data">暂无访问记录</div>
                    <?php endif; ?>
                </div>
            </div>

        <?php else: ?>
            <div class="stat-card">
                <i class="fas fa-chart-bar"></i>
                <div class="stat-label">请输入短链接代码查看统计</div>
                <p style="margin-top: 15px; color: #6c757d;">在URL后添加 ?code=你的短代码 来查看统计信息</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($stats): ?>
    <script>
        // 点击趋势图表
        const clickCtx = document.getElementById('clickChart').getContext('2d');
        const clickChart = new Chart(clickCtx, {
            type: 'line',
            data: {
                labels: [
                    <?php
                    $hours = [];
                    for ($i = 0; $i < 24; $i++) {
                        $hours[] = sprintf("%02d:00", $i);
                    }
                    echo "'" . implode("','", $hours) . "'";
                    ?>
                ],
                datasets: [{
                    label: '点击次数',
                    data: [
                        <?php
                        $hourData = [];
                        for ($i = 0; $i < 24; $i++) {
                            $hourData[] = isset($stats['hourly_distribution'][$i]) ? $stats['hourly_distribution'][$i] : 0;
                        }
                        echo implode(',', $hourData);
                        ?>
                    ],
                    borderColor: '#4facfe',
                    backgroundColor: 'rgba(79, 172, 254, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // 设备分布图表
        const deviceCtx = document.getElementById('deviceChart').getContext('2d');
        const deviceChart = new Chart(deviceCtx, {
            type: 'doughnut',
            data: {
                labels: [
                    <?php
                    if (isset($stats['device_distribution']) && !empty($stats['device_distribution'])) {
                        $devices = array_keys($stats['device_distribution']);
                        echo "'" . implode("','", $devices) . "'";
                    } else {
                        echo "'Desktop'";
                    }
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php
                        if (isset($stats['device_distribution']) && !empty($stats['device_distribution'])) {
                            $deviceCounts = array_values($stats['device_distribution']);
                            echo implode(',', $deviceCounts);
                        } else {
                            echo "1";
                        }
                        ?>
                    ],
                    backgroundColor: [
                        '#4facfe',
                        '#00f2fe',
                        '#43e97b',
                        '#fa709a'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });

        // 浏览器分布图表
        const browserCtx = document.getElementById('browserChart').getContext('2d');
        const browserChart = new Chart(browserCtx, {
            type: 'pie',
            data: {
                labels: [
                    <?php
                    if (isset($stats['browser_distribution']) && !empty($stats['browser_distribution'])) {
                        $browsers = array_keys($stats['browser_distribution']);
                        echo "'" . implode("','", $browsers) . "'";
                    } else {
                        echo "'Unknown'";
                    }
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php
                        if (isset($stats['browser_distribution']) && !empty($stats['browser_distribution'])) {
                            $browserCounts = array_values($stats['browser_distribution']);
                            echo implode(',', $browserCounts);
                        } else {
                            echo "1";
                        }
                        ?>
                    ],
                    backgroundColor: [
                        '#FF6384',
                        '#36A2EB',
                        '#FFCE56',
                        '#4BC0C0',
                        '#9966FF',
                        '#FF9F40'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });

        // 自动刷新数据（每30秒）
        setInterval(() => {
            location.reload();
        }, 30000);
    </script>
    <?php endif; ?>
</body>
</html>