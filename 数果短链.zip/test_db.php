<?php
// test_db.php - 数据库连接测试
define('DB_HOST', 'localhost');
define('DB_USER', 'dl');
define('DB_PASS', 'dl');
define('DB_NAME', 'dl');

echo "<h2>数据库连接测试</h2>";

// 测试连接
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    echo "<p style='color:red'>连接失败: " . $conn->connect_error . "</p>";
} else {
    echo "<p style='color:green'>连接成功!</p>";
    
    // 检查数据库
    $result = $conn->query("SHOW DATABASES LIKE '" . DB_NAME . "'");
    if ($result->num_rows > 0) {
        echo "<p style='color:green'>数据库 '" . DB_NAME . "' 存在</p>";
    } else {
        echo "<p style='color:red'>数据库 '" . DB_NAME . "' 不存在</p>";
    }
    
    // 检查表
    $tables = ['short_urls', 'short_url_access_log', 'short_url_device_stats'];
    foreach ($tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result->num_rows > 0) {
            echo "<p style='color:green'>表 '$table' 存在</p>";
        } else {
            echo "<p style='color:orange'>表 '$table' 不存在</p>";
        }
    }
    
    // 尝试创建表
    echo "<h3>尝试创建表...</h3>";
    $sql = "CREATE TABLE IF NOT EXISTS short_urls (
        id INT AUTO_INCREMENT PRIMARY KEY,
        long_url TEXT NOT NULL,
        short_code VARCHAR(10) UNIQUE NOT NULL,
        clicks INT DEFAULT 0,
        unique_visitors INT DEFAULT 0,
        last_accessed TIMESTAMP NULL,
        title VARCHAR(255) DEFAULT '',
        is_active TINYINT DEFAULT 1,
        expiry_date TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "<p style='color:green'>表创建成功</p>";
    } else {
        echo "<p style='color:red'>表创建失败: " . $conn->error . "</p>";
    }
}

$conn->close();
?>