document.addEventListener('DOMContentLoaded', function() {
    const copyBtn = document.getElementById('copy-btn');
    
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const shortUrl = document.getElementById('short-url');
            const textArea = document.createElement('textarea');
            
            textArea.value = shortUrl.textContent;
            document.body.appendChild(textArea);
            textArea.select();
            
            try {
                const successful = document.execCommand('copy');
                const msg = successful ? '复制成功!' : '复制失败';
                alert(msg);
            } catch (err) {
                alert('浏览器不支持复制功能');
            }
            
            document.body.removeChild(textArea);
        });
    }
});